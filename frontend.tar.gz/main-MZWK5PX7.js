import{$a as ut,A as b,Aa as ri,B as m,Ba as dt,Bb as de,Ca as C,D as F,Da as M,E,Ea as oi,Eb as ht,F as Zt,Fa as ai,G as Qt,Ga as ct,Gb as wi,Ha as mt,Hb as Di,Ia as S,Ib as Te,Ja as d,Jb as Fi,K as X,Ka as he,Kb as Ei,L as I,La as j,Lb as ce,M as Yt,Mb as Si,N as U,O as Ie,Oa as pe,P as ne,Pa as ge,Q as q,Qa as _e,R as k,Ra as w,Sa as si,T as K,Ta as G,U as c,Ua as H,Va as ve,Wa as li,X as Jt,Xa as Z,Y as W,Ya as oe,Z as f,Za as di,a as V,aa as A,b as L,ba as R,bb as ci,c as Tt,ca as h,cb as mi,d as Nt,da as D,db as ui,e as O,ea as re,eb as fi,f as Lt,fa as Xt,fb as hi,g as zt,ga as Kt,gb as pi,h as jt,hb as ae,i as Se,ia as T,ib as gi,j as Ht,ja as p,jb as _i,ka as g,kb as se,l as Bt,la as ei,lb as vi,m as Gt,ma as ti,mb as bi,n as Ve,na as _,nb as xi,oa as a,p as Ut,pa as s,pb as yi,qa as x,qb as Re,r as qt,ra as ii,s as Wt,sa as ni,sb as le,t as Ae,ta as st,tb as ft,u as $t,ua as $,ub as Ci,v as Oe,va as ke,w as Pe,wa as v,x as z,xa as u,xb as Mi,y as J,ya as lt,z as P,za as N,zb as be}from"./chunk-5UZICVG4.js";var Ti=(()=>{class t{_renderer;_elementRef;onChange=e=>{};onTouched=()=>{};constructor(e,n){this._renderer=e,this._elementRef=n}setProperty(e,n){this._renderer.setProperty(this._elementRef.nativeElement,e,n)}registerOnTouched(e){this.onTouched=e}registerOnChange(e){this.onChange=e}setDisabledState(e){this.setProperty("disabled",e)}static \u0275fac=function(n){return new(n||t)(f(W),f(k))};static \u0275dir=h({type:t})}return t})(),Ni=(()=>{class t extends Ti{static \u0275fac=(()=>{let e;return function(r){return(e||(e=q(t)))(r||t)}})();static \u0275dir=h({type:t,features:[D]})}return t})(),gt=new b("");var Ln={provide:gt,useExisting:z(()=>Je),multi:!0};function zn(){let t=ut()?ut().getUserAgent():"";return/android (\d+)/.test(t.toLowerCase())}var jn=new b(""),Je=(()=>{class t extends Ti{_compositionMode;_composing=!1;constructor(e,n,r){super(e,n),this._compositionMode=r,this._compositionMode==null&&(this._compositionMode=!zn())}writeValue(e){let n=e??"";this.setProperty("value",n)}_handleInput(e){(!this._compositionMode||this._compositionMode&&!this._composing)&&this.onChange(e)}_compositionStart(){this._composing=!0}_compositionEnd(e){this._composing=!1,this._compositionMode&&this.onChange(e)}static \u0275fac=function(n){return new(n||t)(f(W),f(k),f(jn,8))};static \u0275dir=h({type:t,selectors:[["input","formControlName","",3,"type","checkbox"],["textarea","formControlName",""],["input","formControl","",3,"type","checkbox"],["textarea","formControl",""],["input","ngModel","",3,"type","checkbox"],["textarea","ngModel",""],["","ngDefaultControl",""]],hostBindings:function(n,r){n&1&&v("input",function(l){return r._handleInput(l.target.value)})("blur",function(){return r.onTouched()})("compositionstart",function(){return r._compositionStart()})("compositionend",function(l){return r._compositionEnd(l.target.value)})},standalone:!1,features:[w([Ln]),D]})}return t})();function _t(t){return t==null||vt(t)===0}function vt(t){return t==null?null:Array.isArray(t)||typeof t=="string"?t.length:t instanceof Set?t.size:null}var te=new b(""),bt=new b(""),Hn=/^(?=.{1,254}$)(?=.{1,64}@)[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/,Le=class{static min(i){return Li(i)}static max(i){return zi(i)}static required(i){return ji(i)}static requiredTrue(i){return Bn(i)}static email(i){return Gn(i)}static minLength(i){return Un(i)}static maxLength(i){return Hi(i)}static pattern(i){return qn(i)}static nullValidator(i){return ze()}static compose(i){return $i(i)}static composeAsync(i){return Zi(i)}};function Li(t){return i=>{if(i.value==null||t==null)return null;let e=parseFloat(i.value);return!isNaN(e)&&e<t?{min:{min:t,actual:i.value}}:null}}function zi(t){return i=>{if(i.value==null||t==null)return null;let e=parseFloat(i.value);return!isNaN(e)&&e>t?{max:{max:t,actual:i.value}}:null}}function ji(t){return _t(t.value)?{required:!0}:null}function Bn(t){return t.value===!0?null:{required:!0}}function Gn(t){return _t(t.value)||Hn.test(t.value)?null:{email:!0}}function Un(t){return i=>{let e=i.value?.length??vt(i.value);return e===null||e===0?null:e<t?{minlength:{requiredLength:t,actualLength:e}}:null}}function Hi(t){return i=>{let e=i.value?.length??vt(i.value);return e!==null&&e>t?{maxlength:{requiredLength:t,actualLength:e}}:null}}function qn(t){if(!t)return ze;let i,e;return typeof t=="string"?(e="",t.charAt(0)!=="^"&&(e+="^"),e+=t,t.charAt(t.length-1)!=="$"&&(e+="$"),i=new RegExp(e)):(e=t.toString(),i=t),n=>{if(_t(n.value))return null;let r=n.value;return i.test(r)?null:{pattern:{requiredPattern:e,actualValue:r}}}}function ze(t){return null}function Bi(t){return t!=null}function Gi(t){return Kt(t)?zt(t):t}function Ui(t){let i={};return t.forEach(e=>{i=e!=null?V(V({},i),e):i}),Object.keys(i).length===0?null:i}function qi(t,i){return i.map(e=>e(t))}function Wn(t){return!t.validate}function Wi(t){return t.map(i=>Wn(i)?i:e=>i.validate(e))}function $i(t){if(!t)return null;let i=t.filter(Bi);return i.length==0?null:function(e){return Ui(qi(e,i))}}function xt(t){return t!=null?$i(Wi(t)):null}function Zi(t){if(!t)return null;let i=t.filter(Bi);return i.length==0?null:function(e){let n=qi(e,i).map(Gi);return Ht(n).pipe(Se(Ui))}}function yt(t){return t!=null?Zi(Wi(t)):null}function Vi(t,i){return t===null?[i]:Array.isArray(t)?[...t,i]:[t,i]}function Qi(t){return t._rawValidators}function Yi(t){return t._rawAsyncValidators}function pt(t){return t?Array.isArray(t)?t:[t]:[]}function je(t,i){return Array.isArray(t)?t.includes(i):t===i}function Ai(t,i){let e=pt(i);return pt(t).forEach(r=>{je(e,r)||e.push(r)}),e}function Oi(t,i){return pt(i).filter(e=>!je(t,e))}var He=class{get value(){return this.control?this.control.value:null}get valid(){return this.control?this.control.valid:null}get invalid(){return this.control?this.control.invalid:null}get pending(){return this.control?this.control.pending:null}get disabled(){return this.control?this.control.disabled:null}get enabled(){return this.control?this.control.enabled:null}get errors(){return this.control?this.control.errors:null}get pristine(){return this.control?this.control.pristine:null}get dirty(){return this.control?this.control.dirty:null}get touched(){return this.control?this.control.touched:null}get status(){return this.control?this.control.status:null}get untouched(){return this.control?this.control.untouched:null}get statusChanges(){return this.control?this.control.statusChanges:null}get valueChanges(){return this.control?this.control.valueChanges:null}get path(){return null}_composedValidatorFn;_composedAsyncValidatorFn;_rawValidators=[];_rawAsyncValidators=[];_setValidators(i){this._rawValidators=i||[],this._composedValidatorFn=xt(this._rawValidators)}_setAsyncValidators(i){this._rawAsyncValidators=i||[],this._composedAsyncValidatorFn=yt(this._rawAsyncValidators)}get validator(){return this._composedValidatorFn||null}get asyncValidator(){return this._composedAsyncValidatorFn||null}_onDestroyCallbacks=[];_registerOnDestroy(i){this._onDestroyCallbacks.push(i)}_invokeOnDestroyCallbacks(){this._onDestroyCallbacks.forEach(i=>i()),this._onDestroyCallbacks=[]}reset(i=void 0){this.control?.reset(i)}hasError(i,e){return this.control?this.control.hasError(i,e):!1}getError(i,e){return this.control?this.control.getError(i,e):null}},Q=class extends He{name;get formDirective(){return null}get path(){return null}},ee=class extends He{_parent=null;name=null;valueAccessor=null},Be=class{_cd;constructor(i){this._cd=i}get isTouched(){return this._cd?.control?._touched?.(),!!this._cd?.control?.touched}get isUntouched(){return!!this._cd?.control?.untouched}get isPristine(){return this._cd?.control?._pristine?.(),!!this._cd?.control?.pristine}get isDirty(){return!!this._cd?.control?.dirty}get isValid(){return this._cd?.control?._status?.(),!!this._cd?.control?.valid}get isInvalid(){return!!this._cd?.control?.invalid}get isPending(){return!!this._cd?.control?.pending}get isSubmitted(){return this._cd?._submitted?.(),!!this._cd?.submitted}};var Ji=(()=>{class t extends Be{constructor(e){super(e)}static \u0275fac=function(n){return new(n||t)(f(ee,2))};static \u0275dir=h({type:t,selectors:[["","formControlName",""],["","ngModel",""],["","formControl",""]],hostVars:14,hostBindings:function(n,r){n&2&&S("ng-untouched",r.isUntouched)("ng-touched",r.isTouched)("ng-pristine",r.isPristine)("ng-dirty",r.isDirty)("ng-valid",r.isValid)("ng-invalid",r.isInvalid)("ng-pending",r.isPending)},standalone:!1,features:[D]})}return t})(),Xi=(()=>{class t extends Be{constructor(e){super(e)}static \u0275fac=function(n){return new(n||t)(f(Q,10))};static \u0275dir=h({type:t,selectors:[["","formGroupName",""],["","formArrayName",""],["","ngModelGroup",""],["","formGroup",""],["","formArray",""],["form",3,"ngNoForm",""],["","ngForm",""]],hostVars:16,hostBindings:function(n,r){n&2&&S("ng-untouched",r.isUntouched)("ng-touched",r.isTouched)("ng-pristine",r.isPristine)("ng-dirty",r.isDirty)("ng-valid",r.isValid)("ng-invalid",r.isInvalid)("ng-pending",r.isPending)("ng-submitted",r.isSubmitted)},standalone:!1,features:[D]})}return t})();var xe="VALID",Ne="INVALID",me="PENDING",ye="DISABLED",Y=class{},Ge=class extends Y{value;source;constructor(i,e){super(),this.value=i,this.source=e}},Me=class extends Y{pristine;source;constructor(i,e){super(),this.pristine=i,this.source=e}},we=class extends Y{touched;source;constructor(i,e){super(),this.touched=i,this.source=e}},ue=class extends Y{status;source;constructor(i,e){super(),this.status=i,this.source=e}},Ue=class extends Y{source;constructor(i){super(),this.source=i}},qe=class extends Y{source;constructor(i){super(),this.source=i}};function Ki(t){return(Xe(t)?t.validators:t)||null}function $n(t){return Array.isArray(t)?xt(t):t||null}function en(t,i){return(Xe(i)?i.asyncValidators:t)||null}function Zn(t){return Array.isArray(t)?yt(t):t||null}function Xe(t){return t!=null&&!Array.isArray(t)&&typeof t=="object"}function Qn(t,i,e){let n=t.controls;if(!(i?Object.keys(n):n).length)throw new Pe(1e3,"");if(!n[e])throw new Pe(1001,"")}function Yn(t,i,e){t._forEachChild((n,r)=>{if(e[r]===void 0)throw new Pe(-1002,"")})}var We=class{_pendingDirty=!1;_hasOwnPendingAsyncValidator=null;_pendingTouched=!1;_onCollectionChange=()=>{};_updateOn;_parent=null;_asyncValidationSubscription;_composedValidatorFn;_composedAsyncValidatorFn;_rawValidators;_rawAsyncValidators;value;constructor(i,e){this._assignValidators(i),this._assignAsyncValidators(e)}get validator(){return this._composedValidatorFn}set validator(i){this._rawValidators=this._composedValidatorFn=i}get asyncValidator(){return this._composedAsyncValidatorFn}set asyncValidator(i){this._rawAsyncValidators=this._composedAsyncValidatorFn=i}get parent(){return this._parent}get status(){return G(this.statusReactive)}set status(i){G(()=>this.statusReactive.set(i))}_status=H(()=>this.statusReactive());statusReactive=U(void 0);get valid(){return this.status===xe}get invalid(){return this.status===Ne}get pending(){return this.status===me}get disabled(){return this.status===ye}get enabled(){return this.status!==ye}errors;get pristine(){return G(this.pristineReactive)}set pristine(i){G(()=>this.pristineReactive.set(i))}_pristine=H(()=>this.pristineReactive());pristineReactive=U(!0);get dirty(){return!this.pristine}get touched(){return G(this.touchedReactive)}set touched(i){G(()=>this.touchedReactive.set(i))}_touched=H(()=>this.touchedReactive());touchedReactive=U(!1);get untouched(){return!this.touched}_events=new O;events=this._events.asObservable();valueChanges;statusChanges;get updateOn(){return this._updateOn?this._updateOn:this.parent?this.parent.updateOn:"change"}setValidators(i){this._assignValidators(i)}setAsyncValidators(i){this._assignAsyncValidators(i)}addValidators(i){this.setValidators(Ai(i,this._rawValidators))}addAsyncValidators(i){this.setAsyncValidators(Ai(i,this._rawAsyncValidators))}removeValidators(i){this.setValidators(Oi(i,this._rawValidators))}removeAsyncValidators(i){this.setAsyncValidators(Oi(i,this._rawAsyncValidators))}hasValidator(i){return je(this._rawValidators,i)}hasAsyncValidator(i){return je(this._rawAsyncValidators,i)}clearValidators(){this.validator=null}clearAsyncValidators(){this.asyncValidator=null}markAsTouched(i={}){let e=this.touched===!1;this.touched=!0;let n=i.sourceControl??this;i.onlySelf||this._parent?.markAsTouched(L(V({},i),{sourceControl:n})),e&&i.emitEvent!==!1&&this._events.next(new we(!0,n))}markAllAsDirty(i={}){this.markAsDirty({onlySelf:!0,emitEvent:i.emitEvent,sourceControl:this}),this._forEachChild(e=>e.markAllAsDirty(i))}markAllAsTouched(i={}){this.markAsTouched({onlySelf:!0,emitEvent:i.emitEvent,sourceControl:this}),this._forEachChild(e=>e.markAllAsTouched(i))}markAsUntouched(i={}){let e=this.touched===!0;this.touched=!1,this._pendingTouched=!1;let n=i.sourceControl??this;this._forEachChild(r=>{r.markAsUntouched({onlySelf:!0,emitEvent:i.emitEvent,sourceControl:n})}),i.onlySelf||this._parent?._updateTouched(i,n),e&&i.emitEvent!==!1&&this._events.next(new we(!1,n))}markAsDirty(i={}){let e=this.pristine===!0;this.pristine=!1;let n=i.sourceControl??this;i.onlySelf||this._parent?.markAsDirty(L(V({},i),{sourceControl:n})),e&&i.emitEvent!==!1&&this._events.next(new Me(!1,n))}markAsPristine(i={}){let e=this.pristine===!1;this.pristine=!0,this._pendingDirty=!1;let n=i.sourceControl??this;this._forEachChild(r=>{r.markAsPristine({onlySelf:!0,emitEvent:i.emitEvent})}),i.onlySelf||this._parent?._updatePristine(i,n),e&&i.emitEvent!==!1&&this._events.next(new Me(!0,n))}markAsPending(i={}){this.status=me;let e=i.sourceControl??this;i.emitEvent!==!1&&(this._events.next(new ue(this.status,e)),this.statusChanges.emit(this.status)),i.onlySelf||this._parent?.markAsPending(L(V({},i),{sourceControl:e}))}disable(i={}){let e=this._parentMarkedDirty(i.onlySelf);this.status=ye,this.errors=null,this._forEachChild(r=>{r.disable(L(V({},i),{onlySelf:!0}))}),this._updateValue();let n=i.sourceControl??this;i.emitEvent!==!1&&(this._events.next(new Ge(this.value,n)),this._events.next(new ue(this.status,n)),this.valueChanges.emit(this.value),this.statusChanges.emit(this.status)),this._updateAncestors(L(V({},i),{skipPristineCheck:e}),this),this._onDisabledChange.forEach(r=>r(!0))}enable(i={}){let e=this._parentMarkedDirty(i.onlySelf);this.status=xe,this._forEachChild(n=>{n.enable(L(V({},i),{onlySelf:!0}))}),this.updateValueAndValidity({onlySelf:!0,emitEvent:i.emitEvent}),this._updateAncestors(L(V({},i),{skipPristineCheck:e}),this),this._onDisabledChange.forEach(n=>n(!1))}_updateAncestors(i,e){i.onlySelf||(this._parent?.updateValueAndValidity(i),i.skipPristineCheck||this._parent?._updatePristine({},e),this._parent?._updateTouched({},e))}setParent(i){this._parent=i}getRawValue(){return this.value}updateValueAndValidity(i={}){if(this._setInitialStatus(),this._updateValue(),this.enabled){let n=this._cancelExistingSubscription();this.errors=this._runValidator(),this.status=this._calculateStatus(),(this.status===xe||this.status===me)&&this._runAsyncValidator(n,i.emitEvent)}let e=i.sourceControl??this;i.emitEvent!==!1&&(this._events.next(new Ge(this.value,e)),this._events.next(new ue(this.status,e)),this.valueChanges.emit(this.value),this.statusChanges.emit(this.status)),i.onlySelf||this._parent?.updateValueAndValidity(L(V({},i),{sourceControl:e}))}_updateTreeValidity(i={emitEvent:!0}){this._forEachChild(e=>e._updateTreeValidity(i)),this.updateValueAndValidity({onlySelf:!0,emitEvent:i.emitEvent})}_setInitialStatus(){this.status=this._allControlsDisabled()?ye:xe}_runValidator(){return this.validator?this.validator(this):null}_runAsyncValidator(i,e){if(this.asyncValidator){this.status=me,this._hasOwnPendingAsyncValidator={emitEvent:e!==!1,shouldHaveEmitted:i!==!1};let n=Gi(this.asyncValidator(this));this._asyncValidationSubscription=n.subscribe(r=>{this._hasOwnPendingAsyncValidator=null,this.setErrors(r,{emitEvent:e,shouldHaveEmitted:i})})}}_cancelExistingSubscription(){if(this._asyncValidationSubscription){this._asyncValidationSubscription.unsubscribe();let i=(this._hasOwnPendingAsyncValidator?.emitEvent||this._hasOwnPendingAsyncValidator?.shouldHaveEmitted)??!1;return this._hasOwnPendingAsyncValidator=null,i}return!1}setErrors(i,e={}){this.errors=i,this._updateControlsErrors(e.emitEvent!==!1,this,e.shouldHaveEmitted)}get(i){let e=i;return e==null||(Array.isArray(e)||(e=e.split(".")),e.length===0)?null:e.reduce((n,r)=>n&&n._find(r),this)}getError(i,e){let n=e?this.get(e):this;return n?.errors?n.errors[i]:null}hasError(i,e){return!!this.getError(i,e)}get root(){let i=this;for(;i._parent;)i=i._parent;return i}_updateControlsErrors(i,e,n){this.status=this._calculateStatus(),i&&this.statusChanges.emit(this.status),(i||n)&&this._events.next(new ue(this.status,e)),this._parent&&this._parent._updateControlsErrors(i,e,n)}_initObservables(){this.valueChanges=new X,this.statusChanges=new X}_calculateStatus(){return this._allControlsDisabled()?ye:this.errors?Ne:this._hasOwnPendingAsyncValidator||this._anyControlsHaveStatus(me)?me:this._anyControlsHaveStatus(Ne)?Ne:xe}_anyControlsHaveStatus(i){return this._anyControls(e=>e.status===i)}_anyControlsDirty(){return this._anyControls(i=>i.dirty)}_anyControlsTouched(){return this._anyControls(i=>i.touched)}_updatePristine(i,e){let n=!this._anyControlsDirty(),r=this.pristine!==n;this.pristine=n,i.onlySelf||this._parent?._updatePristine(i,e),r&&this._events.next(new Me(this.pristine,e))}_updateTouched(i={},e){this.touched=this._anyControlsTouched(),this._events.next(new we(this.touched,e)),i.onlySelf||this._parent?._updateTouched(i,e)}_onDisabledChange=[];_registerOnCollectionChange(i){this._onCollectionChange=i}_setUpdateStrategy(i){Xe(i)&&i.updateOn!=null&&(this._updateOn=i.updateOn)}_parentMarkedDirty(i){return!i&&!!this._parent?.dirty&&!this._parent._anyControlsDirty()}_find(i){return null}_assignValidators(i){this._rawValidators=Array.isArray(i)?i.slice():i,this._composedValidatorFn=$n(this._rawValidators)}_assignAsyncValidators(i){this._rawAsyncValidators=Array.isArray(i)?i.slice():i,this._composedAsyncValidatorFn=Zn(this._rawAsyncValidators)}},$e=class extends We{constructor(i,e,n){super(Ki(e),en(n,e)),this.controls=i,this._initObservables(),this._setUpdateStrategy(e),this._setUpControls(),this.updateValueAndValidity({onlySelf:!0,emitEvent:!!this.asyncValidator})}controls;registerControl(i,e){return this.controls[i]?this.controls[i]:(this.controls[i]=e,e.setParent(this),e._registerOnCollectionChange(this._onCollectionChange),e)}addControl(i,e,n={}){this.registerControl(i,e),this.updateValueAndValidity({emitEvent:n.emitEvent}),this._onCollectionChange()}removeControl(i,e={}){this.controls[i]&&this.controls[i]._registerOnCollectionChange(()=>{}),delete this.controls[i],this.updateValueAndValidity({emitEvent:e.emitEvent}),this._onCollectionChange()}setControl(i,e,n={}){this.controls[i]&&this.controls[i]._registerOnCollectionChange(()=>{}),delete this.controls[i],e&&this.registerControl(i,e),this.updateValueAndValidity({emitEvent:n.emitEvent}),this._onCollectionChange()}contains(i){return this.controls.hasOwnProperty(i)&&this.controls[i].enabled}setValue(i,e={}){Yn(this,!0,i),Object.keys(i).forEach(n=>{Qn(this,!0,n),this.controls[n].setValue(i[n],{onlySelf:!0,emitEvent:e.emitEvent})}),this.updateValueAndValidity(e)}patchValue(i,e={}){i!=null&&(Object.keys(i).forEach(n=>{let r=this.controls[n];r&&r.patchValue(i[n],{onlySelf:!0,emitEvent:e.emitEvent})}),this.updateValueAndValidity(e))}reset(i={},e={}){this._forEachChild((n,r)=>{n.reset(i?i[r]:null,L(V({},e),{onlySelf:!0}))}),this._updatePristine(e,this),this._updateTouched(e,this),this.updateValueAndValidity(e),e?.emitEvent!==!1&&this._events.next(new qe(this))}getRawValue(){return this._reduceChildren({},(i,e,n)=>(i[n]=e.getRawValue(),i))}_syncPendingControls(){let i=this._reduceChildren(!1,(e,n)=>n._syncPendingControls()?!0:e);return i&&this.updateValueAndValidity({onlySelf:!0}),i}_forEachChild(i){Object.keys(this.controls).forEach(e=>{let n=this.controls[e];n&&i(n,e)})}_setUpControls(){this._forEachChild(i=>{i.setParent(this),i._registerOnCollectionChange(this._onCollectionChange)})}_updateValue(){this.value=this._reduceValue()}_anyControls(i){for(let[e,n]of Object.entries(this.controls))if(this.contains(e)&&i(n))return!0;return!1}_reduceValue(){let i={};return this._reduceChildren(i,(e,n,r)=>((n.enabled||this.disabled)&&(e[r]=n.value),e))}_reduceChildren(i,e){let n=i;return this._forEachChild((r,o)=>{n=e(n,r,o)}),n}_allControlsDisabled(){for(let i of Object.keys(this.controls))if(this.controls[i].enabled)return!1;return Object.keys(this.controls).length>0||this.disabled}_find(i){return this.controls.hasOwnProperty(i)?this.controls[i]:null}};var Ke=new b("",{factory:()=>Ct}),Ct="always";function Jn(t,i){return[...i.path,t]}function Ze(t,i,e=Ct){Mt(t,i),i.valueAccessor.writeValue(t.value),(t.disabled||e==="always")&&i.valueAccessor.setDisabledState?.(t.disabled),Kn(t,i),tr(t,i),er(t,i),Xn(t,i)}function Pi(t,i,e=!0){let n=()=>{};i?.valueAccessor?.registerOnChange(n),i?.valueAccessor?.registerOnTouched(n),Ye(t,i),t&&(i._invokeOnDestroyCallbacks(),t._registerOnCollectionChange(()=>{}))}function Qe(t,i){t.forEach(e=>{e.registerOnValidatorChange&&e.registerOnValidatorChange(i)})}function Xn(t,i){if(i.valueAccessor.setDisabledState){let e=n=>{i.valueAccessor.setDisabledState(n)};t.registerOnDisabledChange(e),i._registerOnDestroy(()=>{t._unregisterOnDisabledChange(e)})}}function Mt(t,i){let e=Qi(t);i.validator!==null?t.setValidators(Vi(e,i.validator)):typeof e=="function"&&t.setValidators([e]);let n=Yi(t);i.asyncValidator!==null?t.setAsyncValidators(Vi(n,i.asyncValidator)):typeof n=="function"&&t.setAsyncValidators([n]);let r=()=>t.updateValueAndValidity();Qe(i._rawValidators,r),Qe(i._rawAsyncValidators,r)}function Ye(t,i){let e=!1;if(t!==null){if(i.validator!==null){let r=Qi(t);if(Array.isArray(r)&&r.length>0){let o=r.filter(l=>l!==i.validator);o.length!==r.length&&(e=!0,t.setValidators(o))}}if(i.asyncValidator!==null){let r=Yi(t);if(Array.isArray(r)&&r.length>0){let o=r.filter(l=>l!==i.asyncValidator);o.length!==r.length&&(e=!0,t.setAsyncValidators(o))}}}let n=()=>{};return Qe(i._rawValidators,n),Qe(i._rawAsyncValidators,n),e}function Kn(t,i){i.valueAccessor.registerOnChange(e=>{t._pendingValue=e,t._pendingChange=!0,t._pendingDirty=!0,t.updateOn==="change"&&tn(t,i)})}function er(t,i){i.valueAccessor.registerOnTouched(()=>{t._pendingTouched=!0,t.updateOn==="blur"&&t._pendingChange&&tn(t,i),t.updateOn!=="submit"&&t.markAsTouched()})}function tn(t,i){t._pendingDirty&&t.markAsDirty(),t.setValue(t._pendingValue,{emitModelToViewChange:!1}),i.viewToModelUpdate(t._pendingValue),t._pendingChange=!1}function tr(t,i){let e=(n,r)=>{i.valueAccessor.writeValue(n),r&&i.viewToModelUpdate(n)};t.registerOnChange(e),i._registerOnDestroy(()=>{t._unregisterOnChange(e)})}function nn(t,i){t==null,Mt(t,i)}function ir(t,i){return Ye(t,i)}function nr(t,i){if(!t.hasOwnProperty("model"))return!1;let e=t.model;return e.isFirstChange()?!0:!Object.is(i,e.currentValue)}function rr(t){return Object.getPrototypeOf(t.constructor)===Ni}function rn(t,i){t._syncPendingControls(),i.forEach(e=>{let n=e.control;n.updateOn==="submit"&&n._pendingChange&&(e.viewToModelUpdate(n._pendingValue),n._pendingChange=!1)})}function or(t,i){if(!i)return null;Array.isArray(i);let e,n,r;return i.forEach(o=>{o.constructor===Je?e=o:rr(o)?n=o:r=o}),r||n||e||null}function ar(t,i){let e=t.indexOf(i);e>-1&&t.splice(e,1)}var sr={provide:Q,useExisting:z(()=>De)},Ce=Promise.resolve(),De=(()=>{class t extends Q{callSetDisabledState;get submitted(){return G(this.submittedReactive)}_submitted=H(()=>this.submittedReactive());submittedReactive=U(!1);_directives=new Set;form;ngSubmit=new X;options;constructor(e,n,r){super(),this.callSetDisabledState=r,this.form=new $e({},xt(e),yt(n))}ngAfterViewInit(){this._setUpdateStrategy()}get formDirective(){return this}get control(){return this.form}get path(){return[]}get controls(){return this.form.controls}addControl(e){Ce.then(()=>{let n=this._findContainer(e.path);e.control=n.registerControl(e.name,e.control),Ze(e.control,e,this.callSetDisabledState),e.control.updateValueAndValidity({emitEvent:!1}),this._directives.add(e)})}getControl(e){return this.form.get(e.path)}removeControl(e){Ce.then(()=>{this._findContainer(e.path)?.removeControl(e.name),this._directives.delete(e)})}addFormGroup(e){Ce.then(()=>{let n=this._findContainer(e.path),r=new $e({});nn(r,e),n.registerControl(e.name,r),r.updateValueAndValidity({emitEvent:!1})})}removeFormGroup(e){Ce.then(()=>{this._findContainer(e.path)?.removeControl?.(e.name)})}getFormGroup(e){return this.form.get(e.path)}updateModel(e,n){Ce.then(()=>{this.form.get(e.path).setValue(n)})}setValue(e){this.control.setValue(e)}onSubmit(e){return this.submittedReactive.set(!0),rn(this.form,this._directives),this.ngSubmit.emit(e),this.form._events.next(new Ue(this.control)),e?.target?.method==="dialog"}onReset(){this.resetForm()}resetForm(e=void 0){this.form.reset(e),this.submittedReactive.set(!1)}_setUpdateStrategy(){this.options&&this.options.updateOn!=null&&(this.form._updateOn=this.options.updateOn)}_findContainer(e){return e.pop(),e.length?this.form.get(e):this.form}static \u0275fac=function(n){return new(n||t)(f(te,10),f(bt,10),f(Ke,8))};static \u0275dir=h({type:t,selectors:[["form",3,"ngNoForm","",3,"formGroup","",3,"formArray",""],["ng-form"],["","ngForm",""]],hostBindings:function(n,r){n&1&&v("submit",function(l){return r.onSubmit(l)})("reset",function(){return r.onReset()})},inputs:{options:[0,"ngFormOptions","options"]},outputs:{ngSubmit:"ngSubmit"},exportAs:["ngForm"],standalone:!1,features:[w([sr]),D]})}return t})();function Ii(t,i){let e=t.indexOf(i);e>-1&&t.splice(e,1)}function ki(t){return typeof t=="object"&&t!==null&&Object.keys(t).length===2&&"value"in t&&"disabled"in t}var on=class extends We{defaultValue=null;_onChange=[];_pendingValue;_pendingChange=!1;constructor(i=null,e,n){super(Ki(e),en(n,e)),this._applyFormState(i),this._setUpdateStrategy(e),this._initObservables(),this.updateValueAndValidity({onlySelf:!0,emitEvent:!!this.asyncValidator}),Xe(e)&&(e.nonNullable||e.initialValueIsDefault)&&(ki(i)?this.defaultValue=i.value:this.defaultValue=i)}setValue(i,e={}){this.value=this._pendingValue=i,this._onChange.length&&e.emitModelToViewChange!==!1&&this._onChange.forEach(n=>n(this.value,e.emitViewToModelChange!==!1)),this.updateValueAndValidity(e)}patchValue(i,e={}){this.setValue(i,e)}reset(i=this.defaultValue,e={}){this._applyFormState(i),this.markAsPristine(e),this.markAsUntouched(e),this.setValue(this.value,e),e.overwriteDefaultValue&&(this.defaultValue=this.value),this._pendingChange=!1,e?.emitEvent!==!1&&this._events.next(new qe(this))}_updateValue(){}_anyControls(i){return!1}_allControlsDisabled(){return this.disabled}registerOnChange(i){this._onChange.push(i)}_unregisterOnChange(i){Ii(this._onChange,i)}registerOnDisabledChange(i){this._onDisabledChange.push(i)}_unregisterOnDisabledChange(i){Ii(this._onDisabledChange,i)}_forEachChild(i){}_syncPendingControls(){return this.updateOn==="submit"&&(this._pendingDirty&&this.markAsDirty(),this._pendingTouched&&this.markAsTouched(),this._pendingChange)?(this.setValue(this._pendingValue,{onlySelf:!0,emitModelToViewChange:!1}),!0):!1}_applyFormState(i){ki(i)?(this.value=this._pendingValue=i.value,i.disabled?this.disable({onlySelf:!0,emitEvent:!1}):this.enable({onlySelf:!0,emitEvent:!1})):this.value=this._pendingValue=i}};var lr=t=>t instanceof on;var dr={provide:ee,useExisting:z(()=>wt)},Ri=Promise.resolve(),wt=(()=>{class t extends ee{_changeDetectorRef;callSetDisabledState;control=new on;static ngAcceptInputType_isDisabled;_registered=!1;viewModel;name="";isDisabled;model;options;update=new X;constructor(e,n,r,o,l,y){super(),this._changeDetectorRef=l,this.callSetDisabledState=y,this._parent=e,this._setValidators(n),this._setAsyncValidators(r),this.valueAccessor=or(this,o)}ngOnChanges(e){if(this._checkForErrors(),!this._registered||"name"in e){if(this._registered&&(this._checkName(),this.formDirective)){let n=e.name.previousValue;this.formDirective.removeControl({name:n,path:this._getPath(n)})}this._setUpControl()}"isDisabled"in e&&this._updateDisabled(e),nr(e,this.viewModel)&&(this._updateValue(this.model),this.viewModel=this.model)}ngOnDestroy(){this.formDirective?.removeControl(this)}get path(){return this._getPath(this.name)}get formDirective(){return this._parent?this._parent.formDirective:null}viewToModelUpdate(e){this.viewModel=e,this.update.emit(e)}_setUpControl(){this._setUpdateStrategy(),this._isStandalone()?this._setUpStandalone():this.formDirective.addControl(this),this._registered=!0}_setUpdateStrategy(){this.options&&this.options.updateOn!=null&&(this.control._updateOn=this.options.updateOn)}_isStandalone(){return!this._parent||!!(this.options&&this.options.standalone)}_setUpStandalone(){Ze(this.control,this,this.callSetDisabledState),this.control.updateValueAndValidity({emitEvent:!1})}_checkForErrors(){this._checkName()}_checkName(){this.options&&this.options.name&&(this.name=this.options.name),!this._isStandalone()&&this.name}_updateValue(e){Ri.then(()=>{this.control.setValue(e,{emitViewToModelChange:!1}),this._changeDetectorRef?.markForCheck()})}_updateDisabled(e){let n=e.isDisabled.currentValue,r=n!==0&&oe(n);Ri.then(()=>{r&&!this.control.disabled?this.control.disable():!r&&this.control.disabled&&this.control.enable(),this._changeDetectorRef?.markForCheck()})}_getPath(e){return this._parent?Jn(e,this._parent):[e]}static \u0275fac=function(n){return new(n||t)(f(Q,9),f(te,10),f(bt,10),f(gt,10),f(Z,8),f(Ke,8))};static \u0275dir=h({type:t,selectors:[["","ngModel","",3,"formControlName","",3,"formControl",""]],inputs:{name:"name",isDisabled:[0,"disabled","isDisabled"],model:[0,"ngModel","model"],options:[0,"ngModelOptions","options"]},outputs:{update:"ngModelChange"},exportAs:["ngModel"],standalone:!1,features:[w([dr]),D,ne]})}return t})();var an=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275dir=h({type:t,selectors:[["form",3,"ngNoForm","",3,"ngNativeValidate",""]],hostAttrs:["novalidate",""],standalone:!1})}return t})(),cr={provide:gt,useExisting:z(()=>Dt),multi:!0},Dt=(()=>{class t extends Ni{writeValue(e){let n=e??"";this.setProperty("value",n)}registerOnChange(e){this.onChange=n=>{e(n==""?null:parseFloat(n))}}static \u0275fac=(()=>{let e;return function(r){return(e||(e=q(t)))(r||t)}})();static \u0275dir=h({type:t,selectors:[["input","type","number","formControlName",""],["input","type","number","formControl",""],["input","type","number","ngModel",""]],hostBindings:function(n,r){n&1&&v("input",function(l){return r.onChange(l.target.value)})("blur",function(){return r.onTouched()})},standalone:!1,features:[w([cr]),D]})}return t})();var mr=(()=>{class t extends Q{callSetDisabledState;get submitted(){return G(this._submittedReactive)}set submitted(e){this._submittedReactive.set(e)}_submitted=H(()=>this._submittedReactive());_submittedReactive=U(!1);_oldForm;_onCollectionChange=()=>this._updateDomValue();directives=[];constructor(e,n,r){super(),this.callSetDisabledState=r,this._setValidators(e),this._setAsyncValidators(n)}ngOnChanges(e){this.onChanges(e)}ngOnDestroy(){this.onDestroy()}onChanges(e){this._checkFormPresent(),e.hasOwnProperty("form")&&(this._updateValidators(),this._updateDomValue(),this._updateRegistrations(),this._oldForm=this.form)}onDestroy(){this.form&&(Ye(this.form,this),this.form._onCollectionChange===this._onCollectionChange&&this.form._registerOnCollectionChange(()=>{}))}get formDirective(){return this}get path(){return[]}addControl(e){let n=this.form.get(e.path);return Ze(n,e,this.callSetDisabledState),n.updateValueAndValidity({emitEvent:!1}),this.directives.push(e),n}getControl(e){return this.form.get(e.path)}removeControl(e){Pi(e.control||null,e,!1),ar(this.directives,e)}addFormGroup(e){this._setUpFormContainer(e)}removeFormGroup(e){this._cleanUpFormContainer(e)}getFormGroup(e){return this.form.get(e.path)}getFormArray(e){return this.form.get(e.path)}addFormArray(e){this._setUpFormContainer(e)}removeFormArray(e){this._cleanUpFormContainer(e)}updateModel(e,n){this.form.get(e.path).setValue(n)}onReset(){this.resetForm()}resetForm(e=void 0,n={}){this.form.reset(e,n),this._submittedReactive.set(!1)}onSubmit(e){return this.submitted=!0,rn(this.form,this.directives),this.ngSubmit.emit(e),this.form._events.next(new Ue(this.control)),e?.target?.method==="dialog"}_updateDomValue(){this.directives.forEach(e=>{let n=e.control,r=this.form.get(e.path);n!==r&&(Pi(n||null,e),lr(r)&&(Ze(r,e,this.callSetDisabledState),e.control=r))}),this.form._updateTreeValidity({emitEvent:!1})}_setUpFormContainer(e){let n=this.form.get(e.path);nn(n,e),n.updateValueAndValidity({emitEvent:!1})}_cleanUpFormContainer(e){let n=this.form?.get(e.path);n&&ir(n,e)&&n.updateValueAndValidity({emitEvent:!1})}_updateRegistrations(){this.form._registerOnCollectionChange(this._onCollectionChange),this._oldForm?._registerOnCollectionChange(()=>{})}_updateValidators(){Mt(this.form,this),this._oldForm&&Ye(this._oldForm,this)}_checkFormPresent(){this.form}static \u0275fac=function(n){return new(n||t)(f(te,10),f(bt,10),f(Ke,8))};static \u0275dir=h({type:t,features:[D,ne]})}return t})();var ur={provide:Q,useExisting:z(()=>Ft)},Ft=(()=>{class t extends mr{form=null;ngSubmit=new X;get control(){return this.form}static \u0275fac=(()=>{let e;return function(r){return(e||(e=q(t)))(r||t)}})();static \u0275dir=h({type:t,selectors:[["","formGroup",""]],hostBindings:function(n,r){n&1&&v("submit",function(l){return r.onSubmit(l)})("reset",function(){return r.onReset()})},inputs:{form:[0,"formGroup","form"]},outputs:{ngSubmit:"ngSubmit"},exportAs:["ngForm"],standalone:!1,features:[w([ur]),D]})}return t})();function fr(t){return typeof t=="number"?t:parseInt(t,10)}function sn(t){return typeof t=="number"?t:parseFloat(t)}var et=(()=>{class t{_validator=ze;_onChange;_enabled;ngOnChanges(e){if(this.inputName in e){let n=this.normalizeInput(e[this.inputName].currentValue);this._enabled=this.enabled(n),this._validator=this._enabled?this.createValidator(n):ze,this._onChange?.()}}validate(e){return this._validator(e)}registerOnValidatorChange(e){this._onChange=e}enabled(e){return e!=null}static \u0275fac=function(n){return new(n||t)};static \u0275dir=h({type:t,features:[ne]})}return t})(),hr={provide:te,useExisting:z(()=>Et),multi:!0},Et=(()=>{class t extends et{max;inputName="max";normalizeInput=e=>sn(e);createValidator=e=>zi(e);static \u0275fac=(()=>{let e;return function(r){return(e||(e=q(t)))(r||t)}})();static \u0275dir=h({type:t,selectors:[["input","type","number","max","","formControlName",""],["input","type","number","max","","formControl",""],["input","type","number","max","","ngModel",""]],hostVars:1,hostBindings:function(n,r){n&2&&T("max",r._enabled?r.max:null)},inputs:{max:"max"},standalone:!1,features:[w([hr]),D]})}return t})(),pr={provide:te,useExisting:z(()=>St),multi:!0},St=(()=>{class t extends et{min;inputName="min";normalizeInput=e=>sn(e);createValidator=e=>Li(e);static \u0275fac=(()=>{let e;return function(r){return(e||(e=q(t)))(r||t)}})();static \u0275dir=h({type:t,selectors:[["input","type","number","min","","formControlName",""],["input","type","number","min","","formControl",""],["input","type","number","min","","ngModel",""]],hostVars:1,hostBindings:function(n,r){n&2&&T("min",r._enabled?r.min:null)},inputs:{min:"min"},standalone:!1,features:[w([pr]),D]})}return t})(),gr={provide:te,useExisting:z(()=>Vt),multi:!0};var Vt=(()=>{class t extends et{required;inputName="required";normalizeInput=oe;createValidator=e=>ji;enabled(e){return e}static \u0275fac=(()=>{let e;return function(r){return(e||(e=q(t)))(r||t)}})();static \u0275dir=h({type:t,selectors:[["","required","","formControlName","",3,"type","checkbox"],["","required","","formControl","",3,"type","checkbox"],["","required","","ngModel","",3,"type","checkbox"]],hostVars:1,hostBindings:function(n,r){n&2&&T("required",r._enabled?"":null)},inputs:{required:"required"},standalone:!1,features:[w([gr]),D]})}return t})();var _r={provide:te,useExisting:z(()=>At),multi:!0},At=(()=>{class t extends et{maxlength;inputName="maxlength";normalizeInput=e=>fr(e);createValidator=e=>Hi(e);static \u0275fac=(()=>{let e;return function(r){return(e||(e=q(t)))(r||t)}})();static \u0275dir=h({type:t,selectors:[["","maxlength","","formControlName",""],["","maxlength","","formControl",""],["","maxlength","","ngModel",""]],hostVars:1,hostBindings:function(n,r){n&2&&T("maxlength",r._enabled?r.maxlength:null)},inputs:{maxlength:"maxlength"},standalone:!1,features:[w([_r]),D]})}return t})();var vr=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275mod=R({type:t});static \u0275inj=P({})}return t})();var ln=(()=>{class t{static withConfig(e){return{ngModule:t,providers:[{provide:Ke,useValue:e.callSetDisabledState??Ct}]}}static \u0275fac=function(n){return new(n||t)};static \u0275mod=R({type:t});static \u0275inj=P({imports:[vr]})}return t})();var Ot=class{_box;_destroyed=new O;_resizeSubject=new O;_resizeObserver;_elementObservables=new Map;constructor(i){this._box=i,typeof ResizeObserver<"u"&&(this._resizeObserver=new ResizeObserver(e=>this._resizeSubject.next(e)))}observe(i){return this._elementObservables.has(i)||this._elementObservables.set(i,new Nt(e=>{let n=this._resizeSubject.subscribe(e);return this._resizeObserver?.observe(i,{box:this._box}),()=>{this._resizeObserver?.unobserve(i),n.unsubscribe(),this._elementObservables.delete(i)}}).pipe(Ve(e=>e.some(n=>n.target===i)),Wt({bufferSize:1,refCount:!0}),Oe(this._destroyed))),this._elementObservables.get(i)}destroy(){this._destroyed.next(),this._destroyed.complete(),this._resizeSubject.complete(),this._elementObservables.clear()}},dn=(()=>{class t{_cleanupErrorListener;_observers=new Map;_ngZone=m(I);constructor(){typeof ResizeObserver<"u"}ngOnDestroy(){for(let[,e]of this._observers)e.destroy();this._observers.clear(),this._cleanupErrorListener?.()}observe(e,n){let r=n?.box||"content-box";return this._observers.has(r)||this._observers.set(r,new Ot(r)),this._observers.get(r).observe(e)}static \u0275fac=function(n){return new(n||t)};static \u0275prov=J({token:t,factory:t.\u0275fac,providedIn:"root"})}return t})();var xr=["notch"],yr=["matFormFieldNotchedOutline",""],Cr=["*"],cn=["iconPrefixContainer"],mn=["textPrefixContainer"],un=["iconSuffixContainer"],fn=["textSuffixContainer"],Mr=["textField"],wr=["*",[["mat-label"]],[["","matPrefix",""],["","matIconPrefix",""]],[["","matTextPrefix",""]],[["","matTextSuffix",""]],[["","matSuffix",""],["","matIconSuffix",""]],[["mat-error"],["","matError",""]],[["mat-hint",3,"align","end"]],[["mat-hint","align","end"]]],Dr=["*","mat-label","[matPrefix], [matIconPrefix]","[matTextPrefix]","[matTextSuffix]","[matSuffix], [matIconSuffix]","mat-error, [matError]","mat-hint:not([align='end'])","mat-hint[align='end']"];function Fr(t,i){t&1&&x(0,"span",21)}function Er(t,i){if(t&1&&(a(0,"label",20),N(1,1),p(2,Fr,1,0,"span",21),s()),t&2){let e=u(2);_("floating",e._shouldLabelFloat())("monitorResize",e._hasOutline())("id",e._labelId),T("for",e._control.disableAutomaticLabeling?null:e._control.id),c(2),g(!e.hideRequiredMarker&&e._control.required?2:-1)}}function Sr(t,i){if(t&1&&p(0,Er,3,5,"label",20),t&2){let e=u();g(e._hasFloatingLabel()?0:-1)}}function Vr(t,i){t&1&&x(0,"div",7)}function Ar(t,i){}function Or(t,i){if(t&1&&re(0,Ar,0,0,"ng-template",13),t&2){u(2);let e=mt(1);_("ngTemplateOutlet",e)}}function Pr(t,i){if(t&1&&(a(0,"div",9),p(1,Or,1,1,null,13),s()),t&2){let e=u();_("matFormFieldNotchedOutlineOpen",e._shouldLabelFloat()),c(),g(e._forceDisplayInfixLabel()?-1:1)}}function Ir(t,i){t&1&&(a(0,"div",10,2),N(2,2),s())}function kr(t,i){t&1&&(a(0,"div",11,3),N(2,3),s())}function Rr(t,i){}function Tr(t,i){if(t&1&&re(0,Rr,0,0,"ng-template",13),t&2){u();let e=mt(1);_("ngTemplateOutlet",e)}}function Nr(t,i){t&1&&(a(0,"div",14,4),N(2,4),s())}function Lr(t,i){t&1&&(a(0,"div",15,5),N(2,5),s())}function zr(t,i){t&1&&x(0,"div",16)}function jr(t,i){t&1&&(a(0,"div",18),N(1,6),s())}function Hr(t,i){if(t&1&&(a(0,"mat-hint",22),d(1),s()),t&2){let e=u(2);_("id",e._hintLabelId),c(),he(e.hintLabel)}}function Br(t,i){if(t&1&&(a(0,"div",19),p(1,Hr,2,2,"mat-hint",22),N(2,7),x(3,"div",23),N(4,8),s()),t&2){let e=u();c(),g(e.hintLabel?1:-1)}}var Fe=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275dir=h({type:t,selectors:[["mat-label"]]})}return t})(),Gr=new b("MatError");var Pt=(()=>{class t{align="start";id=m(be).getId("mat-mdc-hint-");static \u0275fac=function(n){return new(n||t)};static \u0275dir=h({type:t,selectors:[["mat-hint"]],hostAttrs:[1,"mat-mdc-form-field-hint","mat-mdc-form-field-bottom-align"],hostVars:4,hostBindings:function(n,r){n&2&&(ke("id",r.id),T("align",null),S("mat-mdc-form-field-hint-end",r.align==="end"))},inputs:{align:"align",id:"id"}})}return t})(),xn=new b("MatPrefix"),It=(()=>{class t{set _isTextSelector(e){this._isText=!0}_isText=!1;static \u0275fac=function(n){return new(n||t)};static \u0275dir=h({type:t,selectors:[["","matPrefix",""],["","matIconPrefix",""],["","matTextPrefix",""]],inputs:{_isTextSelector:[0,"matTextPrefix","_isTextSelector"]},features:[w([{provide:xn,useExisting:t}])]})}return t})(),Ur=new b("MatSuffix");var yn=new b("FloatingLabelParent"),hn=(()=>{class t{_elementRef=m(k);get floating(){return this._floating}set floating(e){this._floating=e,this.monitorResize&&this._handleResize()}_floating=!1;get monitorResize(){return this._monitorResize}set monitorResize(e){this._monitorResize=e,this._monitorResize?this._subscribeToResize():this._resizeSubscription.unsubscribe()}_monitorResize=!1;_resizeObserver=m(dn);_ngZone=m(I);_parent=m(yn);_resizeSubscription=new Tt;constructor(){}ngOnDestroy(){this._resizeSubscription.unsubscribe()}getWidth(){return qr(this._elementRef.nativeElement)}get element(){return this._elementRef.nativeElement}_handleResize(){setTimeout(()=>this._parent._handleLabelResized())}_subscribeToResize(){this._resizeSubscription.unsubscribe(),this._ngZone.runOutsideAngular(()=>{this._resizeSubscription=this._resizeObserver.observe(this._elementRef.nativeElement,{box:"border-box"}).subscribe(()=>this._handleResize())})}static \u0275fac=function(n){return new(n||t)};static \u0275dir=h({type:t,selectors:[["label","matFormFieldFloatingLabel",""]],hostAttrs:[1,"mdc-floating-label","mat-mdc-floating-label"],hostVars:2,hostBindings:function(n,r){n&2&&S("mdc-floating-label--float-above",r.floating)},inputs:{floating:"floating",monitorResize:"monitorResize"}})}return t})();function qr(t){let i=t;if(i.offsetParent!==null)return i.scrollWidth;let e=i.cloneNode(!0);e.style.setProperty("position","absolute"),e.style.setProperty("transform","translate(-9999px, -9999px)"),document.documentElement.appendChild(e);let n=e.scrollWidth;return e.remove(),n}var pn="mdc-line-ripple--active",tt="mdc-line-ripple--deactivating",gn=(()=>{class t{_elementRef=m(k);_cleanupTransitionEnd;constructor(){let e=m(I),n=m(W);e.runOutsideAngular(()=>{this._cleanupTransitionEnd=n.listen(this._elementRef.nativeElement,"transitionend",this._handleTransitionEnd)})}activate(){let e=this._elementRef.nativeElement.classList;e.remove(tt),e.add(pn)}deactivate(){this._elementRef.nativeElement.classList.add(tt)}_handleTransitionEnd=e=>{let n=this._elementRef.nativeElement.classList,r=n.contains(tt);e.propertyName==="opacity"&&r&&n.remove(pn,tt)};ngOnDestroy(){this._cleanupTransitionEnd()}static \u0275fac=function(n){return new(n||t)};static \u0275dir=h({type:t,selectors:[["div","matFormFieldLineRipple",""]],hostAttrs:[1,"mdc-line-ripple"]})}return t})(),_n=(()=>{class t{_elementRef=m(k);_ngZone=m(I);open=!1;_notch;ngAfterViewInit(){let e=this._elementRef.nativeElement,n=e.querySelector(".mdc-floating-label");n?(e.classList.add("mdc-notched-outline--upgraded"),typeof requestAnimationFrame=="function"&&(n.style.transitionDuration="0s",this._ngZone.runOutsideAngular(()=>{requestAnimationFrame(()=>n.style.transitionDuration="")}))):e.classList.add("mdc-notched-outline--no-label")}_setNotchWidth(e){let n=this._notch.nativeElement;!this.open||!e?n.style.width="":n.style.width=`calc(${e}px * var(--mat-mdc-form-field-floating-label-scale, 0.75) + 9px)`}_setMaxWidth(e){this._notch.nativeElement.style.setProperty("--mat-form-field-notch-max-width",`calc(100% - ${e}px)`)}static \u0275fac=function(n){return new(n||t)};static \u0275cmp=A({type:t,selectors:[["div","matFormFieldNotchedOutline",""]],viewQuery:function(n,r){if(n&1&&dt(xr,5),n&2){let o;C(o=M())&&(r._notch=o.first)}},hostAttrs:[1,"mdc-notched-outline"],hostVars:2,hostBindings:function(n,r){n&2&&S("mdc-notched-outline--notched",r.open)},inputs:{open:[0,"matFormFieldNotchedOutlineOpen","open"]},attrs:yr,ngContentSelectors:Cr,decls:5,vars:0,consts:[["notch",""],[1,"mat-mdc-notch-piece","mdc-notched-outline__leading"],[1,"mat-mdc-notch-piece","mdc-notched-outline__notch"],[1,"mat-mdc-notch-piece","mdc-notched-outline__trailing"]],template:function(n,r){n&1&&(lt(),st(0,"div",1),ii(1,"div",2,0),N(3),ni(),st(4,"div",3))},encapsulation:2,changeDetection:0})}return t})(),kt=(()=>{class t{value=null;stateChanges;id;placeholder;ngControl=null;focused=!1;empty=!1;shouldLabelFloat=!1;required=!1;disabled=!1;errorState=!1;controlType;autofilled;userAriaDescribedBy;disableAutomaticLabeling;describedByIds;static \u0275fac=function(n){return new(n||t)};static \u0275dir=h({type:t})}return t})();var Rt=new b("MatFormField"),Wr=new b("MAT_FORM_FIELD_DEFAULT_OPTIONS"),vn="fill",$r="auto",bn="fixed",Zr="translateY(-50%)",it=(()=>{class t{_elementRef=m(k);_changeDetectorRef=m(Z);_platform=m(le);_idGenerator=m(be);_ngZone=m(I);_defaults=m(Wr,{optional:!0});_currentDirection;_textField;_iconPrefixContainer;_textPrefixContainer;_iconSuffixContainer;_textSuffixContainer;_floatingLabel;_notchedOutline;_lineRipple;_iconPrefixContainerSignal=ve("iconPrefixContainer");_textPrefixContainerSignal=ve("textPrefixContainer");_iconSuffixContainerSignal=ve("iconSuffixContainer");_textSuffixContainerSignal=ve("textSuffixContainer");_prefixSuffixContainers=H(()=>[this._iconPrefixContainerSignal(),this._textPrefixContainerSignal(),this._iconSuffixContainerSignal(),this._textSuffixContainerSignal()].map(e=>e?.nativeElement).filter(e=>e!==void 0));_formFieldControl;_prefixChildren;_suffixChildren;_errorChildren;_hintChildren;_labelChild=li(Fe);get hideRequiredMarker(){return this._hideRequiredMarker}set hideRequiredMarker(e){this._hideRequiredMarker=de(e)}_hideRequiredMarker=!1;color="primary";get floatLabel(){return this._floatLabel||this._defaults?.floatLabel||$r}set floatLabel(e){e!==this._floatLabel&&(this._floatLabel=e,this._changeDetectorRef.markForCheck())}_floatLabel;get appearance(){return this._appearanceSignal()}set appearance(e){let n=e||this._defaults?.appearance||vn;this._appearanceSignal.set(n)}_appearanceSignal=U(vn);get subscriptSizing(){return this._subscriptSizing||this._defaults?.subscriptSizing||bn}set subscriptSizing(e){this._subscriptSizing=e||this._defaults?.subscriptSizing||bn}_subscriptSizing=null;get hintLabel(){return this._hintLabel}set hintLabel(e){this._hintLabel=e,this._processHints()}_hintLabel="";_hasIconPrefix=!1;_hasTextPrefix=!1;_hasIconSuffix=!1;_hasTextSuffix=!1;_labelId=this._idGenerator.getId("mat-mdc-form-field-label-");_hintLabelId=this._idGenerator.getId("mat-mdc-hint-");_describedByIds;get _control(){return this._explicitFormFieldControl||this._formFieldControl}set _control(e){this._explicitFormFieldControl=e}_destroyed=new O;_isFocused=null;_explicitFormFieldControl;_previousControl=null;_previousControlValidatorFn=null;_stateChanges;_valueChanges;_describedByChanges;_outlineLabelOffsetResizeObserver=null;_animationsDisabled=wi();constructor(){let e=this._defaults,n=m(_i);e&&(e.appearance&&(this.appearance=e.appearance),this._hideRequiredMarker=!!e?.hideRequiredMarker,e.color&&(this.color=e.color)),Ie(()=>this._currentDirection=n.valueSignal()),this._syncOutlineLabelOffset()}ngAfterViewInit(){this._updateFocusState(),this._animationsDisabled||this._ngZone.runOutsideAngular(()=>{setTimeout(()=>{this._elementRef.nativeElement.classList.add("mat-form-field-animations-enabled")},300)}),this._changeDetectorRef.detectChanges()}ngAfterContentInit(){this._assertFormFieldControl(),this._initializeSubscript(),this._initializePrefixAndSuffix()}ngAfterContentChecked(){this._assertFormFieldControl(),this._control!==this._previousControl&&(this._initializeControl(this._previousControl),this._control.ngControl&&this._control.ngControl.control&&(this._previousControlValidatorFn=this._control.ngControl.control.validator),this._previousControl=this._control),this._control.ngControl&&this._control.ngControl.control&&this._control.ngControl.control.validator!==this._previousControlValidatorFn&&this._changeDetectorRef.markForCheck()}ngOnDestroy(){this._outlineLabelOffsetResizeObserver?.disconnect(),this._stateChanges?.unsubscribe(),this._valueChanges?.unsubscribe(),this._describedByChanges?.unsubscribe(),this._destroyed.next(),this._destroyed.complete()}getLabelId=H(()=>this._hasFloatingLabel()?this._labelId:null);getConnectedOverlayOrigin(){return this._textField||this._elementRef}_animateAndLockLabel(){this._hasFloatingLabel()&&(this.floatLabel="always")}_initializeControl(e){let n=this._control,r="mat-mdc-form-field-type-";e&&this._elementRef.nativeElement.classList.remove(r+e.controlType),n.controlType&&this._elementRef.nativeElement.classList.add(r+n.controlType),this._stateChanges?.unsubscribe(),this._stateChanges=n.stateChanges.subscribe(()=>{this._updateFocusState(),this._changeDetectorRef.markForCheck()}),this._describedByChanges?.unsubscribe(),this._describedByChanges=n.stateChanges.pipe(Ae([void 0,void 0]),Se(()=>[n.errorState,n.userAriaDescribedBy]),qt(),Ve(([[o,l],[y,fe]])=>o!==y||l!==fe)).subscribe(()=>this._syncDescribedByIds()),this._valueChanges?.unsubscribe(),n.ngControl&&n.ngControl.valueChanges&&(this._valueChanges=n.ngControl.valueChanges.pipe(Oe(this._destroyed)).subscribe(()=>this._changeDetectorRef.markForCheck()))}_checkPrefixAndSuffixTypes(){this._hasIconPrefix=!!this._prefixChildren.find(e=>!e._isText),this._hasTextPrefix=!!this._prefixChildren.find(e=>e._isText),this._hasIconSuffix=!!this._suffixChildren.find(e=>!e._isText),this._hasTextSuffix=!!this._suffixChildren.find(e=>e._isText)}_initializePrefixAndSuffix(){this._checkPrefixAndSuffixTypes(),Gt(this._prefixChildren.changes,this._suffixChildren.changes).subscribe(()=>{this._checkPrefixAndSuffixTypes(),this._changeDetectorRef.markForCheck()})}_initializeSubscript(){this._hintChildren.changes.subscribe(()=>{this._processHints(),this._changeDetectorRef.markForCheck()}),this._errorChildren.changes.subscribe(()=>{this._syncDescribedByIds(),this._changeDetectorRef.markForCheck()}),this._validateHints(),this._syncDescribedByIds()}_assertFormFieldControl(){this._control}_updateFocusState(){let e=this._control.focused;e&&!this._isFocused?(this._isFocused=!0,this._lineRipple?.activate()):!e&&(this._isFocused||this._isFocused===null)&&(this._isFocused=!1,this._lineRipple?.deactivate()),this._elementRef.nativeElement.classList.toggle("mat-focused",e),this._textField?.nativeElement.classList.toggle("mdc-text-field--focused",e)}_syncOutlineLabelOffset(){di({earlyRead:()=>{if(this._appearanceSignal()!=="outline")return this._outlineLabelOffsetResizeObserver?.disconnect(),null;if(globalThis.ResizeObserver){this._outlineLabelOffsetResizeObserver||=new globalThis.ResizeObserver(()=>{this._writeOutlinedLabelStyles(this._getOutlinedLabelOffset())});for(let e of this._prefixSuffixContainers())this._outlineLabelOffsetResizeObserver.observe(e,{box:"border-box"})}return this._getOutlinedLabelOffset()},write:e=>this._writeOutlinedLabelStyles(e())})}_shouldAlwaysFloat(){return this.floatLabel==="always"}_hasOutline(){return this.appearance==="outline"}_forceDisplayInfixLabel(){return!this._platform.isBrowser&&this._prefixChildren.length&&!this._shouldLabelFloat()}_hasFloatingLabel=H(()=>!!this._labelChild());_shouldLabelFloat(){return this._hasFloatingLabel()?this._control.shouldLabelFloat||this._shouldAlwaysFloat():!1}_shouldForward(e){let n=this._control?this._control.ngControl:null;return n&&n[e]}_getSubscriptMessageType(){return this._errorChildren&&this._errorChildren.length>0&&this._control.errorState?"error":"hint"}_handleLabelResized(){this._refreshOutlineNotchWidth()}_refreshOutlineNotchWidth(){!this._hasOutline()||!this._floatingLabel||!this._shouldLabelFloat()?this._notchedOutline?._setNotchWidth(0):this._notchedOutline?._setNotchWidth(this._floatingLabel.getWidth())}_processHints(){this._validateHints(),this._syncDescribedByIds()}_validateHints(){this._hintChildren}_syncDescribedByIds(){if(this._control){let e=[];if(this._control.userAriaDescribedBy&&typeof this._control.userAriaDescribedBy=="string"&&e.push(...this._control.userAriaDescribedBy.split(" ")),this._getSubscriptMessageType()==="hint"){let o=this._hintChildren?this._hintChildren.find(y=>y.align==="start"):null,l=this._hintChildren?this._hintChildren.find(y=>y.align==="end"):null;o?e.push(o.id):this._hintLabel&&e.push(this._hintLabelId),l&&e.push(l.id)}else this._errorChildren&&e.push(...this._errorChildren.map(o=>o.id));let n=this._control.describedByIds,r;if(n){let o=this._describedByIds||e;r=e.concat(n.filter(l=>l&&!o.includes(l)))}else r=e;this._control.setDescribedByIds(r),this._describedByIds=e}}_getOutlinedLabelOffset(){if(!this._hasOutline()||!this._floatingLabel)return null;if(!this._iconPrefixContainer&&!this._textPrefixContainer)return["",null];if(!this._isAttachedToDom())return null;let e=this._iconPrefixContainer?.nativeElement,n=this._textPrefixContainer?.nativeElement,r=this._iconSuffixContainer?.nativeElement,o=this._textSuffixContainer?.nativeElement,l=e?.getBoundingClientRect().width??0,y=n?.getBoundingClientRect().width??0,fe=r?.getBoundingClientRect().width??0,ie=o?.getBoundingClientRect().width??0,In=this._currentDirection==="rtl"?"-1":"1",kn=`${l+y}px`,Rn=`calc(${In} * (${kn} + var(--mat-mdc-form-field-label-offset-x, 0px)))`,Tn=`var(--mat-mdc-form-field-label-transform, ${Zr} translateX(${Rn}))`,Nn=l+y+fe+ie;return[Tn,Nn]}_writeOutlinedLabelStyles(e){if(e!==null){let[n,r]=e;this._floatingLabel&&(this._floatingLabel.element.style.transform=n),r!==null&&this._notchedOutline?._setMaxWidth(r)}}_isAttachedToDom(){let e=this._elementRef.nativeElement;if(e.getRootNode){let n=e.getRootNode();return n&&n!==e}return document.documentElement.contains(e)}static \u0275fac=function(n){return new(n||t)};static \u0275cmp=A({type:t,selectors:[["mat-form-field"]],contentQueries:function(n,r,o){if(n&1&&(oi(o,r._labelChild,Fe,5),ri(o,kt,5)(o,xn,5)(o,Ur,5)(o,Gr,5)(o,Pt,5)),n&2){ct();let l;C(l=M())&&(r._formFieldControl=l.first),C(l=M())&&(r._prefixChildren=l),C(l=M())&&(r._suffixChildren=l),C(l=M())&&(r._errorChildren=l),C(l=M())&&(r._hintChildren=l)}},viewQuery:function(n,r){if(n&1&&(ai(r._iconPrefixContainerSignal,cn,5)(r._textPrefixContainerSignal,mn,5)(r._iconSuffixContainerSignal,un,5)(r._textSuffixContainerSignal,fn,5),dt(Mr,5)(cn,5)(mn,5)(un,5)(fn,5)(hn,5)(_n,5)(gn,5)),n&2){ct(4);let o;C(o=M())&&(r._textField=o.first),C(o=M())&&(r._iconPrefixContainer=o.first),C(o=M())&&(r._textPrefixContainer=o.first),C(o=M())&&(r._iconSuffixContainer=o.first),C(o=M())&&(r._textSuffixContainer=o.first),C(o=M())&&(r._floatingLabel=o.first),C(o=M())&&(r._notchedOutline=o.first),C(o=M())&&(r._lineRipple=o.first)}},hostAttrs:[1,"mat-mdc-form-field"],hostVars:38,hostBindings:function(n,r){n&2&&S("mat-mdc-form-field-label-always-float",r._shouldAlwaysFloat())("mat-mdc-form-field-has-icon-prefix",r._hasIconPrefix)("mat-mdc-form-field-has-icon-suffix",r._hasIconSuffix)("mat-form-field-invalid",r._control.errorState)("mat-form-field-disabled",r._control.disabled)("mat-form-field-autofilled",r._control.autofilled)("mat-form-field-appearance-fill",r.appearance=="fill")("mat-form-field-appearance-outline",r.appearance=="outline")("mat-form-field-hide-placeholder",r._hasFloatingLabel()&&!r._shouldLabelFloat())("mat-primary",r.color!=="accent"&&r.color!=="warn")("mat-accent",r.color==="accent")("mat-warn",r.color==="warn")("ng-untouched",r._shouldForward("untouched"))("ng-touched",r._shouldForward("touched"))("ng-pristine",r._shouldForward("pristine"))("ng-dirty",r._shouldForward("dirty"))("ng-valid",r._shouldForward("valid"))("ng-invalid",r._shouldForward("invalid"))("ng-pending",r._shouldForward("pending"))},inputs:{hideRequiredMarker:"hideRequiredMarker",color:"color",floatLabel:"floatLabel",appearance:"appearance",subscriptSizing:"subscriptSizing",hintLabel:"hintLabel"},exportAs:["matFormField"],features:[w([{provide:Rt,useExisting:t},{provide:yn,useExisting:t}])],ngContentSelectors:Dr,decls:18,vars:21,consts:[["labelTemplate",""],["textField",""],["iconPrefixContainer",""],["textPrefixContainer",""],["textSuffixContainer",""],["iconSuffixContainer",""],[1,"mat-mdc-text-field-wrapper","mdc-text-field",3,"click"],[1,"mat-mdc-form-field-focus-overlay"],[1,"mat-mdc-form-field-flex"],["matFormFieldNotchedOutline","",3,"matFormFieldNotchedOutlineOpen"],[1,"mat-mdc-form-field-icon-prefix"],[1,"mat-mdc-form-field-text-prefix"],[1,"mat-mdc-form-field-infix"],[3,"ngTemplateOutlet"],[1,"mat-mdc-form-field-text-suffix"],[1,"mat-mdc-form-field-icon-suffix"],["matFormFieldLineRipple",""],["aria-atomic","true","aria-live","polite",1,"mat-mdc-form-field-subscript-wrapper","mat-mdc-form-field-bottom-align"],[1,"mat-mdc-form-field-error-wrapper"],[1,"mat-mdc-form-field-hint-wrapper"],["matFormFieldFloatingLabel","",3,"floating","monitorResize","id"],["aria-hidden","true",1,"mat-mdc-form-field-required-marker","mdc-floating-label--required"],[3,"id"],[1,"mat-mdc-form-field-hint-spacer"]],template:function(n,r){if(n&1&&(lt(wr),re(0,Sr,1,1,"ng-template",null,0,si),a(2,"div",6,1),v("click",function(l){return r._control.onContainerClick(l)}),p(4,Vr,1,0,"div",7),a(5,"div",8),p(6,Pr,2,2,"div",9),p(7,Ir,3,0,"div",10),p(8,kr,3,0,"div",11),a(9,"div",12),p(10,Tr,1,1,null,13),N(11),s(),p(12,Nr,3,0,"div",14),p(13,Lr,3,0,"div",15),s(),p(14,zr,1,0,"div",16),s(),a(15,"div",17),p(16,jr,2,0,"div",18)(17,Br,5,1,"div",19),s()),n&2){let o;c(2),S("mdc-text-field--filled",!r._hasOutline())("mdc-text-field--outlined",r._hasOutline())("mdc-text-field--no-label",!r._hasFloatingLabel())("mdc-text-field--disabled",r._control.disabled)("mdc-text-field--invalid",r._control.errorState),c(2),g(!r._hasOutline()&&!r._control.disabled?4:-1),c(2),g(r._hasOutline()?6:-1),c(),g(r._hasIconPrefix?7:-1),c(),g(r._hasTextPrefix?8:-1),c(2),g(!r._hasOutline()||r._forceDisplayInfixLabel()?10:-1),c(2),g(r._hasTextSuffix?12:-1),c(),g(r._hasIconSuffix?13:-1),c(),g(r._hasOutline()?-1:14),c(),S("mat-mdc-form-field-subscript-dynamic-size",r.subscriptSizing==="dynamic");let l=r._getSubscriptMessageType();c(),g((o=l)==="error"?16:o==="hint"?17:-1)}},dependencies:[hn,_n,mi,gn,Pt],styles:[`.mdc-text-field {
  display: inline-flex;
  align-items: baseline;
  padding: 0 16px;
  position: relative;
  box-sizing: border-box;
  overflow: hidden;
  will-change: opacity, transform, color;
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
}

.mdc-text-field__input {
  width: 100%;
  min-width: 0;
  border: none;
  border-radius: 0;
  background: none;
  padding: 0;
  -moz-appearance: none;
  -webkit-appearance: none;
  height: 28px;
}
.mdc-text-field__input::-webkit-calendar-picker-indicator, .mdc-text-field__input::-webkit-search-cancel-button {
  display: none;
}
.mdc-text-field__input::-ms-clear {
  display: none;
}
.mdc-text-field__input:focus {
  outline: none;
}
.mdc-text-field__input:invalid {
  box-shadow: none;
}
.mdc-text-field__input::placeholder {
  opacity: 0;
}
.mdc-text-field__input::-moz-placeholder {
  opacity: 0;
}
.mdc-text-field__input::-webkit-input-placeholder {
  opacity: 0;
}
.mdc-text-field__input:-ms-input-placeholder {
  opacity: 0;
}
.mdc-text-field--no-label .mdc-text-field__input::placeholder, .mdc-text-field--focused .mdc-text-field__input::placeholder {
  opacity: 1;
}
.mdc-text-field--no-label .mdc-text-field__input::-moz-placeholder, .mdc-text-field--focused .mdc-text-field__input::-moz-placeholder {
  opacity: 1;
}
.mdc-text-field--no-label .mdc-text-field__input::-webkit-input-placeholder, .mdc-text-field--focused .mdc-text-field__input::-webkit-input-placeholder {
  opacity: 1;
}
.mdc-text-field--no-label .mdc-text-field__input:-ms-input-placeholder, .mdc-text-field--focused .mdc-text-field__input:-ms-input-placeholder {
  opacity: 1;
}
.mdc-text-field--disabled:not(.mdc-text-field--no-label) .mdc-text-field__input.mat-mdc-input-disabled-interactive::placeholder {
  opacity: 0;
}
.mdc-text-field--disabled:not(.mdc-text-field--no-label) .mdc-text-field__input.mat-mdc-input-disabled-interactive::-moz-placeholder {
  opacity: 0;
}
.mdc-text-field--disabled:not(.mdc-text-field--no-label) .mdc-text-field__input.mat-mdc-input-disabled-interactive::-webkit-input-placeholder {
  opacity: 0;
}
.mdc-text-field--disabled:not(.mdc-text-field--no-label) .mdc-text-field__input.mat-mdc-input-disabled-interactive:-ms-input-placeholder {
  opacity: 0;
}
.mdc-text-field--outlined .mdc-text-field__input, .mdc-text-field--filled.mdc-text-field--no-label .mdc-text-field__input {
  height: 100%;
}
.mdc-text-field--outlined .mdc-text-field__input {
  display: flex;
  border: none !important;
  background-color: transparent;
}
.mdc-text-field--disabled .mdc-text-field__input {
  pointer-events: auto;
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-text-field__input {
  color: var(--mat-form-field-filled-input-text-color, var(--mat-sys-on-surface));
  caret-color: var(--mat-form-field-filled-caret-color, var(--mat-sys-primary));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-text-field__input::placeholder {
  color: var(--mat-form-field-filled-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-text-field__input::-moz-placeholder {
  color: var(--mat-form-field-filled-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-text-field__input::-webkit-input-placeholder {
  color: var(--mat-form-field-filled-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-text-field__input:-ms-input-placeholder {
  color: var(--mat-form-field-filled-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-text-field__input {
  color: var(--mat-form-field-outlined-input-text-color, var(--mat-sys-on-surface));
  caret-color: var(--mat-form-field-outlined-caret-color, var(--mat-sys-primary));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-text-field__input::placeholder {
  color: var(--mat-form-field-outlined-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-text-field__input::-moz-placeholder {
  color: var(--mat-form-field-outlined-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-text-field__input::-webkit-input-placeholder {
  color: var(--mat-form-field-outlined-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-text-field__input:-ms-input-placeholder {
  color: var(--mat-form-field-outlined-input-text-placeholder-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled.mdc-text-field--invalid:not(.mdc-text-field--disabled) .mdc-text-field__input {
  caret-color: var(--mat-form-field-filled-error-caret-color, var(--mat-sys-error));
}
.mdc-text-field--outlined.mdc-text-field--invalid:not(.mdc-text-field--disabled) .mdc-text-field__input {
  caret-color: var(--mat-form-field-outlined-error-caret-color, var(--mat-sys-error));
}
.mdc-text-field--filled.mdc-text-field--disabled .mdc-text-field__input {
  color: var(--mat-form-field-filled-disabled-input-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mdc-text-field--outlined.mdc-text-field--disabled .mdc-text-field__input {
  color: var(--mat-form-field-outlined-disabled-input-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
@media (forced-colors: active) {
  .mdc-text-field--disabled .mdc-text-field__input {
    background-color: Window;
  }
}

.mdc-text-field--filled {
  height: 56px;
  border-bottom-right-radius: 0;
  border-bottom-left-radius: 0;
  border-top-left-radius: var(--mat-form-field-filled-container-shape, var(--mat-sys-corner-extra-small));
  border-top-right-radius: var(--mat-form-field-filled-container-shape, var(--mat-sys-corner-extra-small));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) {
  background-color: var(--mat-form-field-filled-container-color, var(--mat-sys-surface-variant));
}
.mdc-text-field--filled.mdc-text-field--disabled {
  background-color: var(--mat-form-field-filled-disabled-container-color, color-mix(in srgb, var(--mat-sys-on-surface) 4%, transparent));
}

.mdc-text-field--outlined {
  height: 56px;
  overflow: visible;
  padding-right: max(16px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small)));
  padding-left: max(16px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small)) + 4px);
}
[dir=rtl] .mdc-text-field--outlined {
  padding-right: max(16px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small)) + 4px);
  padding-left: max(16px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small)));
}

.mdc-floating-label {
  position: absolute;
  left: 0;
  transform-origin: left top;
  line-height: 1.15rem;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
  cursor: text;
  overflow: hidden;
  will-change: transform;
}
[dir=rtl] .mdc-floating-label {
  right: 0;
  left: auto;
  transform-origin: right top;
  text-align: right;
}
.mdc-text-field .mdc-floating-label {
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
}
.mdc-notched-outline .mdc-floating-label {
  display: inline-block;
  position: relative;
  max-width: 100%;
}
.mdc-text-field--outlined .mdc-floating-label {
  left: 4px;
  right: auto;
}
[dir=rtl] .mdc-text-field--outlined .mdc-floating-label {
  left: auto;
  right: 4px;
}
.mdc-text-field--filled .mdc-floating-label {
  left: 16px;
  right: auto;
}
[dir=rtl] .mdc-text-field--filled .mdc-floating-label {
  left: auto;
  right: 16px;
}
.mdc-text-field--disabled .mdc-floating-label {
  cursor: default;
}
@media (forced-colors: active) {
  .mdc-text-field--disabled .mdc-floating-label {
    z-index: 1;
  }
}
.mdc-text-field--filled.mdc-text-field--no-label .mdc-floating-label {
  display: none;
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-floating-label {
  color: var(--mat-form-field-filled-label-text-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--focused .mdc-floating-label {
  color: var(--mat-form-field-filled-focus-label-text-color, var(--mat-sys-primary));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled):not(.mdc-text-field--focused):hover .mdc-floating-label {
  color: var(--mat-form-field-filled-hover-label-text-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled.mdc-text-field--disabled .mdc-floating-label {
  color: var(--mat-form-field-filled-disabled-label-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--invalid .mdc-floating-label {
  color: var(--mat-form-field-filled-error-label-text-color, var(--mat-sys-error));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--invalid.mdc-text-field--focused .mdc-floating-label {
  color: var(--mat-form-field-filled-error-focus-label-text-color, var(--mat-sys-error));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--invalid:not(.mdc-text-field--disabled):hover .mdc-floating-label {
  color: var(--mat-form-field-filled-error-hover-label-text-color, var(--mat-sys-on-error-container));
}
.mdc-text-field--filled .mdc-floating-label {
  font-family: var(--mat-form-field-filled-label-text-font, var(--mat-sys-body-large-font));
  font-size: var(--mat-form-field-filled-label-text-size, var(--mat-sys-body-large-size));
  font-weight: var(--mat-form-field-filled-label-text-weight, var(--mat-sys-body-large-weight));
  letter-spacing: var(--mat-form-field-filled-label-text-tracking, var(--mat-sys-body-large-tracking));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mdc-floating-label {
  color: var(--mat-form-field-outlined-label-text-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--focused .mdc-floating-label {
  color: var(--mat-form-field-outlined-focus-label-text-color, var(--mat-sys-primary));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled):not(.mdc-text-field--focused):hover .mdc-floating-label {
  color: var(--mat-form-field-outlined-hover-label-text-color, var(--mat-sys-on-surface));
}
.mdc-text-field--outlined.mdc-text-field--disabled .mdc-floating-label {
  color: var(--mat-form-field-outlined-disabled-label-text-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid .mdc-floating-label {
  color: var(--mat-form-field-outlined-error-label-text-color, var(--mat-sys-error));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid.mdc-text-field--focused .mdc-floating-label {
  color: var(--mat-form-field-outlined-error-focus-label-text-color, var(--mat-sys-error));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid:not(.mdc-text-field--disabled):hover .mdc-floating-label {
  color: var(--mat-form-field-outlined-error-hover-label-text-color, var(--mat-sys-on-error-container));
}
.mdc-text-field--outlined .mdc-floating-label {
  font-family: var(--mat-form-field-outlined-label-text-font, var(--mat-sys-body-large-font));
  font-size: var(--mat-form-field-outlined-label-text-size, var(--mat-sys-body-large-size));
  font-weight: var(--mat-form-field-outlined-label-text-weight, var(--mat-sys-body-large-weight));
  letter-spacing: var(--mat-form-field-outlined-label-text-tracking, var(--mat-sys-body-large-tracking));
}

.mdc-floating-label--float-above {
  cursor: auto;
  transform: translateY(-106%) scale(0.75);
}
.mdc-text-field--filled .mdc-floating-label--float-above {
  transform: translateY(-106%) scale(0.75);
}
.mdc-text-field--outlined .mdc-floating-label--float-above {
  transform: translateY(-37.25px) scale(1);
  font-size: 0.75rem;
}
.mdc-notched-outline .mdc-floating-label--float-above {
  text-overflow: clip;
}
.mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  max-width: 133.3333333333%;
}
.mdc-text-field--outlined.mdc-notched-outline--upgraded .mdc-floating-label--float-above, .mdc-text-field--outlined .mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  transform: translateY(-34.75px) scale(0.75);
}
.mdc-text-field--outlined.mdc-notched-outline--upgraded .mdc-floating-label--float-above, .mdc-text-field--outlined .mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  font-size: 1rem;
}

.mdc-floating-label--required:not(.mdc-floating-label--hide-required-marker)::after {
  margin-left: 1px;
  margin-right: 0;
  content: "*";
}
[dir=rtl] .mdc-floating-label--required:not(.mdc-floating-label--hide-required-marker)::after {
  margin-left: 0;
  margin-right: 1px;
}

.mdc-notched-outline {
  display: flex;
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  box-sizing: border-box;
  width: 100%;
  max-width: 100%;
  height: 100%;
  text-align: left;
  pointer-events: none;
}
[dir=rtl] .mdc-notched-outline {
  text-align: right;
}
.mdc-text-field--outlined .mdc-notched-outline {
  z-index: 1;
}

.mat-mdc-notch-piece {
  box-sizing: border-box;
  height: 100%;
  pointer-events: none;
  border: none;
  border-top: 1px solid;
  border-bottom: 1px solid;
}
.mdc-text-field--focused .mat-mdc-notch-piece {
  border-width: 2px;
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled) .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-outline-color, var(--mat-sys-outline));
  border-width: var(--mat-form-field-outlined-outline-width, 1px);
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled):not(.mdc-text-field--focused):hover .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-hover-outline-color, var(--mat-sys-on-surface));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--focused .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-focus-outline-color, var(--mat-sys-primary));
}
.mdc-text-field--outlined.mdc-text-field--disabled .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-disabled-outline-color, color-mix(in srgb, var(--mat-sys-on-surface) 12%, transparent));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-error-outline-color, var(--mat-sys-error));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid:not(.mdc-text-field--focused):hover .mdc-notched-outline .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-error-hover-outline-color, var(--mat-sys-on-error-container));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--invalid.mdc-text-field--focused .mat-mdc-notch-piece {
  border-color: var(--mat-form-field-outlined-error-focus-outline-color, var(--mat-sys-error));
}
.mdc-text-field--outlined:not(.mdc-text-field--disabled).mdc-text-field--focused .mdc-notched-outline .mat-mdc-notch-piece {
  border-width: var(--mat-form-field-outlined-focus-outline-width, 2px);
}

.mdc-notched-outline__leading {
  border-left: 1px solid;
  border-right: none;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  border-top-left-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
  border-bottom-left-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
}
.mdc-text-field--outlined .mdc-notched-outline .mdc-notched-outline__leading {
  width: max(12px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small)));
}
[dir=rtl] .mdc-notched-outline__leading {
  border-left: none;
  border-right: 1px solid;
  border-bottom-left-radius: 0;
  border-top-left-radius: 0;
  border-top-right-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
  border-bottom-right-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
}

.mdc-notched-outline__trailing {
  flex-grow: 1;
  border-left: none;
  border-right: 1px solid;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
  border-top-right-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
  border-bottom-right-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
}
[dir=rtl] .mdc-notched-outline__trailing {
  border-left: 1px solid;
  border-right: none;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  border-top-left-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
  border-bottom-left-radius: var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small));
}

.mdc-notched-outline__notch {
  flex: 0 0 auto;
  width: auto;
}
.mdc-text-field--outlined .mdc-notched-outline .mdc-notched-outline__notch {
  max-width: min(var(--mat-form-field-notch-max-width, 100%), calc(100% - max(12px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small))) * 2));
}
.mdc-text-field--outlined .mdc-notched-outline--notched .mdc-notched-outline__notch {
  max-width: min(100%, calc(100% - max(12px, var(--mat-form-field-outlined-container-shape, var(--mat-sys-corner-extra-small))) * 2));
}
.mdc-text-field--outlined .mdc-notched-outline--notched .mdc-notched-outline__notch {
  padding-top: 1px;
}
.mdc-text-field--focused.mdc-text-field--outlined .mdc-notched-outline--notched .mdc-notched-outline__notch {
  padding-top: 2px;
}
.mdc-notched-outline--notched .mdc-notched-outline__notch {
  padding-left: 0;
  padding-right: 8px;
  border-top: none;
}
[dir=rtl] .mdc-notched-outline--notched .mdc-notched-outline__notch {
  padding-left: 8px;
  padding-right: 0;
}
.mdc-notched-outline--no-label .mdc-notched-outline__notch {
  display: none;
}

.mdc-line-ripple::before, .mdc-line-ripple::after {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  border-bottom-style: solid;
  content: "";
}
.mdc-line-ripple::before {
  z-index: 1;
  border-bottom-width: var(--mat-form-field-filled-active-indicator-height, 1px);
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-line-ripple::before {
  border-bottom-color: var(--mat-form-field-filled-active-indicator-color, var(--mat-sys-on-surface-variant));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled):not(.mdc-text-field--focused):hover .mdc-line-ripple::before {
  border-bottom-color: var(--mat-form-field-filled-hover-active-indicator-color, var(--mat-sys-on-surface));
}
.mdc-text-field--filled.mdc-text-field--disabled .mdc-line-ripple::before {
  border-bottom-color: var(--mat-form-field-filled-disabled-active-indicator-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--invalid .mdc-line-ripple::before {
  border-bottom-color: var(--mat-form-field-filled-error-active-indicator-color, var(--mat-sys-error));
}
.mdc-text-field--filled:not(.mdc-text-field--disabled).mdc-text-field--invalid:not(.mdc-text-field--focused):hover .mdc-line-ripple::before {
  border-bottom-color: var(--mat-form-field-filled-error-hover-active-indicator-color, var(--mat-sys-on-error-container));
}
.mdc-line-ripple::after {
  transform: scaleX(0);
  opacity: 0;
  z-index: 2;
}
.mdc-text-field--filled .mdc-line-ripple::after {
  border-bottom-width: var(--mat-form-field-filled-focus-active-indicator-height, 2px);
}
.mdc-text-field--filled:not(.mdc-text-field--disabled) .mdc-line-ripple::after {
  border-bottom-color: var(--mat-form-field-filled-focus-active-indicator-color, var(--mat-sys-primary));
}
.mdc-text-field--filled.mdc-text-field--invalid:not(.mdc-text-field--disabled) .mdc-line-ripple::after {
  border-bottom-color: var(--mat-form-field-filled-error-focus-active-indicator-color, var(--mat-sys-error));
}

.mdc-line-ripple--active::after {
  transform: scaleX(1);
  opacity: 1;
}

.mdc-line-ripple--deactivating::after {
  opacity: 0;
}

.mdc-text-field--disabled {
  pointer-events: none;
}

.mat-mdc-form-field-textarea-control {
  vertical-align: middle;
  resize: vertical;
  box-sizing: border-box;
  height: auto;
  margin: 0;
  padding: 0;
  border: none;
  overflow: auto;
}

.mat-mdc-form-field-input-control.mat-mdc-form-field-input-control {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  font: inherit;
  letter-spacing: inherit;
  text-decoration: inherit;
  text-transform: inherit;
  border: none;
}

.mat-mdc-form-field .mat-mdc-floating-label.mdc-floating-label {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  line-height: normal;
  pointer-events: all;
  will-change: auto;
}

.mat-mdc-form-field:not(.mat-form-field-disabled) .mat-mdc-floating-label.mdc-floating-label {
  cursor: inherit;
}

.mdc-text-field--no-label:not(.mdc-text-field--textarea) .mat-mdc-form-field-input-control.mdc-text-field__input,
.mat-mdc-text-field-wrapper .mat-mdc-form-field-input-control {
  height: auto;
}

.mat-mdc-text-field-wrapper .mat-mdc-form-field-input-control.mdc-text-field__input[type=color] {
  height: 23px;
}

.mat-mdc-text-field-wrapper {
  height: auto;
  flex: auto;
  will-change: auto;
}

.mat-mdc-form-field-has-icon-prefix .mat-mdc-text-field-wrapper {
  padding-left: 0;
  --mat-mdc-form-field-label-offset-x: -16px;
}

.mat-mdc-form-field-has-icon-suffix .mat-mdc-text-field-wrapper {
  padding-right: 0;
}

[dir=rtl] .mat-mdc-text-field-wrapper {
  padding-left: 16px;
  padding-right: 16px;
}
[dir=rtl] .mat-mdc-form-field-has-icon-suffix .mat-mdc-text-field-wrapper {
  padding-left: 0;
}
[dir=rtl] .mat-mdc-form-field-has-icon-prefix .mat-mdc-text-field-wrapper {
  padding-right: 0;
}

.mat-form-field-disabled .mdc-text-field__input::placeholder {
  color: var(--mat-form-field-disabled-input-text-placeholder-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-form-field-disabled .mdc-text-field__input::-moz-placeholder {
  color: var(--mat-form-field-disabled-input-text-placeholder-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-form-field-disabled .mdc-text-field__input::-webkit-input-placeholder {
  color: var(--mat-form-field-disabled-input-text-placeholder-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-form-field-disabled .mdc-text-field__input:-ms-input-placeholder {
  color: var(--mat-form-field-disabled-input-text-placeholder-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}

.mat-mdc-form-field-label-always-float .mdc-text-field__input::placeholder {
  transition-delay: 40ms;
  transition-duration: 110ms;
  opacity: 1;
}

.mat-mdc-text-field-wrapper .mat-mdc-form-field-infix .mat-mdc-floating-label {
  left: auto;
  right: auto;
}

.mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-text-field__input {
  display: inline-block;
}

.mat-mdc-form-field .mat-mdc-text-field-wrapper.mdc-text-field .mdc-notched-outline__notch {
  padding-top: 0;
}

.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field .mdc-notched-outline__notch {
  border-left: 1px solid transparent;
}

[dir=rtl] .mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field.mat-mdc-form-field .mdc-notched-outline__notch {
  border-left: none;
  border-right: 1px solid transparent;
}

.mat-mdc-form-field-infix {
  min-height: var(--mat-form-field-container-height, 56px);
  padding-top: var(--mat-form-field-filled-with-label-container-padding-top, 24px);
  padding-bottom: var(--mat-form-field-filled-with-label-container-padding-bottom, 8px);
}
.mdc-text-field--outlined .mat-mdc-form-field-infix, .mdc-text-field--no-label .mat-mdc-form-field-infix {
  padding-top: var(--mat-form-field-container-vertical-padding, 16px);
  padding-bottom: var(--mat-form-field-container-vertical-padding, 16px);
}

.mat-mdc-text-field-wrapper .mat-mdc-form-field-flex .mat-mdc-floating-label {
  top: calc(var(--mat-form-field-container-height, 56px) / 2);
}

.mdc-text-field--filled .mat-mdc-floating-label {
  display: var(--mat-form-field-filled-label-display, block);
}

.mat-mdc-text-field-wrapper.mdc-text-field--outlined .mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  --mat-mdc-form-field-label-transform: translateY(calc(calc(6.75px + var(--mat-form-field-container-height, 56px) / 2) * -1))
    scale(var(--mat-mdc-form-field-floating-label-scale, 0.75));
  transform: var(--mat-mdc-form-field-label-transform);
}

@keyframes _mat-form-field-subscript-animation {
  from {
    opacity: 0;
    transform: translateY(-5px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
.mat-mdc-form-field-subscript-wrapper {
  box-sizing: border-box;
  width: 100%;
  position: relative;
}

.mat-mdc-form-field-hint-wrapper,
.mat-mdc-form-field-error-wrapper {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  padding: 0 16px;
  opacity: 1;
  transform: translateY(0);
  animation: _mat-form-field-subscript-animation 0ms cubic-bezier(0.55, 0, 0.55, 0.2);
}

.mat-mdc-form-field-subscript-dynamic-size .mat-mdc-form-field-hint-wrapper,
.mat-mdc-form-field-subscript-dynamic-size .mat-mdc-form-field-error-wrapper {
  position: static;
}

.mat-mdc-form-field-bottom-align::before {
  content: "";
  display: inline-block;
  height: 16px;
}

.mat-mdc-form-field-bottom-align.mat-mdc-form-field-subscript-dynamic-size::before {
  content: unset;
}

.mat-mdc-form-field-hint-end {
  order: 1;
}

.mat-mdc-form-field-hint-wrapper {
  display: flex;
}

.mat-mdc-form-field-hint-spacer {
  flex: 1 0 1em;
}

.mat-mdc-form-field-error {
  display: block;
  color: var(--mat-form-field-error-text-color, var(--mat-sys-error));
}

.mat-mdc-form-field-subscript-wrapper,
.mat-mdc-form-field-bottom-align::before {
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  font-family: var(--mat-form-field-subscript-text-font, var(--mat-sys-body-small-font));
  line-height: var(--mat-form-field-subscript-text-line-height, var(--mat-sys-body-small-line-height));
  font-size: var(--mat-form-field-subscript-text-size, var(--mat-sys-body-small-size));
  letter-spacing: var(--mat-form-field-subscript-text-tracking, var(--mat-sys-body-small-tracking));
  font-weight: var(--mat-form-field-subscript-text-weight, var(--mat-sys-body-small-weight));
}

.mat-mdc-form-field-focus-overlay {
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  position: absolute;
  opacity: 0;
  pointer-events: none;
  background-color: var(--mat-form-field-state-layer-color, var(--mat-sys-on-surface));
}
.mat-mdc-text-field-wrapper:hover .mat-mdc-form-field-focus-overlay {
  opacity: var(--mat-form-field-hover-state-layer-opacity, var(--mat-sys-hover-state-layer-opacity));
}
.mat-mdc-form-field.mat-focused .mat-mdc-form-field-focus-overlay {
  opacity: var(--mat-form-field-focus-state-layer-opacity, 0);
}

select.mat-mdc-form-field-input-control {
  -moz-appearance: none;
  -webkit-appearance: none;
  background-color: transparent;
  display: inline-flex;
  box-sizing: border-box;
}
select.mat-mdc-form-field-input-control:not(:disabled) {
  cursor: pointer;
}
select.mat-mdc-form-field-input-control:not(.mat-mdc-native-select-inline) option {
  color: var(--mat-form-field-select-option-text-color, var(--mat-sys-neutral10));
}
select.mat-mdc-form-field-input-control:not(.mat-mdc-native-select-inline) option:disabled {
  color: var(--mat-form-field-select-disabled-option-text-color, color-mix(in srgb, var(--mat-sys-neutral10) 38%, transparent));
}

.mat-mdc-form-field-type-mat-native-select .mat-mdc-form-field-infix::after {
  content: "";
  width: 0;
  height: 0;
  border-left: 5px solid transparent;
  border-right: 5px solid transparent;
  border-top: 5px solid;
  position: absolute;
  right: 0;
  top: 50%;
  margin-top: -2.5px;
  pointer-events: none;
  color: var(--mat-form-field-enabled-select-arrow-color, var(--mat-sys-on-surface-variant));
}
[dir=rtl] .mat-mdc-form-field-type-mat-native-select .mat-mdc-form-field-infix::after {
  right: auto;
  left: 0;
}
.mat-mdc-form-field-type-mat-native-select.mat-focused .mat-mdc-form-field-infix::after {
  color: var(--mat-form-field-focus-select-arrow-color, var(--mat-sys-primary));
}
.mat-mdc-form-field-type-mat-native-select.mat-form-field-disabled .mat-mdc-form-field-infix::after {
  color: var(--mat-form-field-disabled-select-arrow-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-mdc-form-field-type-mat-native-select .mat-mdc-form-field-input-control {
  padding-right: 15px;
}
[dir=rtl] .mat-mdc-form-field-type-mat-native-select .mat-mdc-form-field-input-control {
  padding-right: 0;
  padding-left: 15px;
}

@media (forced-colors: active) {
  .mat-form-field-appearance-fill .mat-mdc-text-field-wrapper {
    outline: solid 1px;
  }
}
@media (forced-colors: active) {
  .mat-form-field-appearance-fill.mat-form-field-disabled .mat-mdc-text-field-wrapper {
    outline-color: GrayText;
  }
}

@media (forced-colors: active) {
  .mat-form-field-appearance-fill.mat-focused .mat-mdc-text-field-wrapper {
    outline: dashed 3px;
  }
}

@media (forced-colors: active) {
  .mat-mdc-form-field.mat-focused .mdc-notched-outline {
    border: dashed 3px;
  }
}

.mat-mdc-form-field-input-control[type=date], .mat-mdc-form-field-input-control[type=datetime], .mat-mdc-form-field-input-control[type=datetime-local], .mat-mdc-form-field-input-control[type=month], .mat-mdc-form-field-input-control[type=week], .mat-mdc-form-field-input-control[type=time] {
  line-height: 1;
}
.mat-mdc-form-field-input-control::-webkit-datetime-edit {
  line-height: 1;
  padding: 0;
  margin-bottom: -2px;
}

.mat-mdc-form-field {
  --mat-mdc-form-field-floating-label-scale: 0.75;
  display: inline-flex;
  flex-direction: column;
  min-width: 0;
  text-align: left;
  -moz-osx-font-smoothing: grayscale;
  -webkit-font-smoothing: antialiased;
  font-family: var(--mat-form-field-container-text-font, var(--mat-sys-body-large-font));
  line-height: var(--mat-form-field-container-text-line-height, var(--mat-sys-body-large-line-height));
  font-size: var(--mat-form-field-container-text-size, var(--mat-sys-body-large-size));
  letter-spacing: var(--mat-form-field-container-text-tracking, var(--mat-sys-body-large-tracking));
  font-weight: var(--mat-form-field-container-text-weight, var(--mat-sys-body-large-weight));
}
.mat-mdc-form-field .mdc-text-field--outlined .mdc-floating-label--float-above {
  font-size: calc(var(--mat-form-field-outlined-label-text-populated-size) * var(--mat-mdc-form-field-floating-label-scale));
}
.mat-mdc-form-field .mdc-text-field--outlined .mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  font-size: var(--mat-form-field-outlined-label-text-populated-size);
}
[dir=rtl] .mat-mdc-form-field {
  text-align: right;
}

.mat-mdc-form-field-flex {
  display: inline-flex;
  align-items: baseline;
  box-sizing: border-box;
  width: 100%;
}

.mat-mdc-text-field-wrapper {
  width: 100%;
  z-index: 0;
}

.mat-mdc-form-field-icon-prefix,
.mat-mdc-form-field-icon-suffix {
  align-self: center;
  line-height: 0;
  pointer-events: auto;
  position: relative;
  z-index: 1;
}
.mat-mdc-form-field-icon-prefix > .mat-icon,
.mat-mdc-form-field-icon-suffix > .mat-icon {
  padding: 0 12px;
  box-sizing: content-box;
}

.mat-mdc-form-field-icon-prefix {
  color: var(--mat-form-field-leading-icon-color, var(--mat-sys-on-surface-variant));
}
.mat-form-field-disabled .mat-mdc-form-field-icon-prefix {
  color: var(--mat-form-field-disabled-leading-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}

.mat-mdc-form-field-icon-suffix {
  color: var(--mat-form-field-trailing-icon-color, var(--mat-sys-on-surface-variant));
}
.mat-form-field-disabled .mat-mdc-form-field-icon-suffix {
  color: var(--mat-form-field-disabled-trailing-icon-color, color-mix(in srgb, var(--mat-sys-on-surface) 38%, transparent));
}
.mat-form-field-invalid .mat-mdc-form-field-icon-suffix {
  color: var(--mat-form-field-error-trailing-icon-color, var(--mat-sys-error));
}
.mat-form-field-invalid:not(.mat-focused):not(.mat-form-field-disabled) .mat-mdc-text-field-wrapper:hover .mat-mdc-form-field-icon-suffix {
  color: var(--mat-form-field-error-hover-trailing-icon-color, var(--mat-sys-on-error-container));
}
.mat-form-field-invalid.mat-focused .mat-mdc-text-field-wrapper .mat-mdc-form-field-icon-suffix {
  color: var(--mat-form-field-error-focus-trailing-icon-color, var(--mat-sys-error));
}

.mat-mdc-form-field-icon-prefix,
[dir=rtl] .mat-mdc-form-field-icon-suffix {
  padding: 0 4px 0 0;
}

.mat-mdc-form-field-icon-suffix,
[dir=rtl] .mat-mdc-form-field-icon-prefix {
  padding: 0 0 0 4px;
}

.mat-mdc-form-field-subscript-wrapper .mat-icon,
.mat-mdc-form-field label .mat-icon {
  width: 1em;
  height: 1em;
  font-size: inherit;
}

.mat-mdc-form-field-infix {
  flex: auto;
  min-width: 0;
  width: 180px;
  position: relative;
  box-sizing: border-box;
}
.mat-mdc-form-field-infix:has(textarea[cols]) {
  width: auto;
}

.mat-mdc-form-field .mdc-notched-outline__notch {
  margin-left: -1px;
  -webkit-clip-path: inset(-9em -999em -9em 1px);
  clip-path: inset(-9em -999em -9em 1px);
}
[dir=rtl] .mat-mdc-form-field .mdc-notched-outline__notch {
  margin-left: 0;
  margin-right: -1px;
  -webkit-clip-path: inset(-9em 1px -9em -999em);
  clip-path: inset(-9em 1px -9em -999em);
}

.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-floating-label {
  transition: transform 150ms cubic-bezier(0.4, 0, 0.2, 1), color 150ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field__input {
  transition: opacity 150ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field__input::placeholder {
  transition: opacity 67ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field__input::-moz-placeholder {
  transition: opacity 67ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field__input::-webkit-input-placeholder {
  transition: opacity 67ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field__input:-ms-input-placeholder {
  transition: opacity 67ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--no-label .mdc-text-field__input::placeholder, .mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--focused .mdc-text-field__input::placeholder {
  transition-delay: 40ms;
  transition-duration: 110ms;
}
.mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--no-label .mdc-text-field__input::-moz-placeholder, .mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--focused .mdc-text-field__input::-moz-placeholder {
  transition-delay: 40ms;
  transition-duration: 110ms;
}
.mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--no-label .mdc-text-field__input::-webkit-input-placeholder, .mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--focused .mdc-text-field__input::-webkit-input-placeholder {
  transition-delay: 40ms;
  transition-duration: 110ms;
}
.mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--no-label .mdc-text-field__input:-ms-input-placeholder, .mat-mdc-form-field.mat-form-field-animations-enabled.mdc-text-field--focused .mdc-text-field__input:-ms-input-placeholder {
  transition-delay: 40ms;
  transition-duration: 110ms;
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-text-field--filled:not(.mdc-ripple-upgraded):focus .mdc-text-field__ripple::before {
  transition-duration: 75ms;
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mdc-line-ripple::after {
  transition: transform 180ms cubic-bezier(0.4, 0, 0.2, 1), opacity 180ms cubic-bezier(0.4, 0, 0.2, 1);
}
.mat-mdc-form-field.mat-form-field-animations-enabled .mat-mdc-form-field-hint-wrapper,
.mat-mdc-form-field.mat-form-field-animations-enabled .mat-mdc-form-field-error-wrapper {
  animation-duration: 300ms;
}

.mdc-notched-outline .mdc-floating-label {
  max-width: calc(100% + 1px);
}

.mdc-notched-outline--upgraded .mdc-floating-label--float-above {
  max-width: calc(133.3333333333% + 1px);
}
`],encapsulation:2,changeDetection:0})}return t})();var Ee=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275mod=R({type:t});static \u0275inj=P({imports:[Mi,it,se]})}return t})();var Yr=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275cmp=A({type:t,selectors:[["ng-component"]],hostAttrs:["cdk-text-field-style-loader",""],decls:0,vars:0,template:function(n,r){},styles:[`textarea.cdk-textarea-autosize {
  resize: none;
}

textarea.cdk-textarea-autosize-measuring {
  padding: 2px 0 !important;
  box-sizing: content-box !important;
  height: auto !important;
  overflow: hidden !important;
}

textarea.cdk-textarea-autosize-measuring-firefox {
  padding: 2px 0 !important;
  box-sizing: content-box !important;
  height: 0 !important;
}

@keyframes cdk-text-field-autofill-start { /*!*/ }
@keyframes cdk-text-field-autofill-end { /*!*/ }
.cdk-text-field-autofill-monitored:-webkit-autofill {
  animation: cdk-text-field-autofill-start 0s 1ms;
}

.cdk-text-field-autofill-monitored:not(:-webkit-autofill) {
  animation: cdk-text-field-autofill-end 0s 1ms;
}
`],encapsulation:2,changeDetection:0})}return t})(),Jr={passive:!0},Cn=(()=>{class t{_platform=m(le);_ngZone=m(I);_renderer=m(Jt).createRenderer(null,null);_styleLoader=m(Ci);_monitoredElements=new Map;constructor(){}monitor(e){if(!this._platform.isBrowser)return Lt;this._styleLoader.load(Yr);let n=ft(e),r=this._monitoredElements.get(n);if(r)return r.subject;let o=new O,l="cdk-text-field-autofilled",y=ie=>{ie.animationName==="cdk-text-field-autofill-start"&&!n.classList.contains(l)?(n.classList.add(l),this._ngZone.run(()=>o.next({target:ie.target,isAutofilled:!0}))):ie.animationName==="cdk-text-field-autofill-end"&&n.classList.contains(l)&&(n.classList.remove(l),this._ngZone.run(()=>o.next({target:ie.target,isAutofilled:!1})))},fe=this._ngZone.runOutsideAngular(()=>(n.classList.add("cdk-text-field-autofill-monitored"),this._renderer.listen(n,"animationstart",y,Jr)));return this._monitoredElements.set(n,{subject:o,unlisten:fe}),o}stopMonitoring(e){let n=ft(e),r=this._monitoredElements.get(n);r&&(r.unlisten(),r.subject.complete(),n.classList.remove("cdk-text-field-autofill-monitored"),n.classList.remove("cdk-text-field-autofilled"),this._monitoredElements.delete(n))}ngOnDestroy(){this._monitoredElements.forEach((e,n)=>this.stopMonitoring(n))}static \u0275fac=function(n){return new(n||t)};static \u0275prov=J({token:t,factory:t.\u0275fac,providedIn:"root"})}return t})();var Mn=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275mod=R({type:t});static \u0275inj=P({})}return t})();var wn=new b("MAT_INPUT_VALUE_ACCESSOR");var Dn=(()=>{class t{isErrorState(e,n){return!!(e&&e.invalid&&(e.touched||n&&n.submitted))}static \u0275fac=function(n){return new(n||t)};static \u0275prov=J({token:t,factory:t.\u0275fac,providedIn:"root"})}return t})();var nt=class{_defaultMatcher;ngControl;_parentFormGroup;_parentForm;_stateChanges;errorState=!1;matcher;constructor(i,e,n,r,o){this._defaultMatcher=i,this.ngControl=e,this._parentFormGroup=n,this._parentForm=r,this._stateChanges=o}updateErrorState(){let i=this.errorState,e=this._parentFormGroup||this._parentForm,n=this.matcher||this._defaultMatcher,r=this.ngControl?this.ngControl.control:null,o=n?.isErrorState(r,e)??!1;o!==i&&(this.errorState=o,this._stateChanges.next())}};var Xr=["button","checkbox","file","hidden","image","radio","range","reset","submit"],Kr=new b("MAT_INPUT_CONFIG"),Fn=(()=>{class t{_elementRef=m(k);_platform=m(le);ngControl=m(ee,{optional:!0,self:!0});_autofillMonitor=m(Cn);_ngZone=m(I);_formField=m(Rt,{optional:!0});_renderer=m(W);_uid=m(be).getId("mat-input-");_previousNativeValue;_inputValueAccessor;_signalBasedValueAccessor;_previousPlaceholder=null;_errorStateTracker;_config=m(Kr,{optional:!0});_cleanupIosKeyup;_cleanupWebkitWheel;_isServer=!1;_isNativeSelect=!1;_isTextarea=!1;_isInFormField=!1;focused=!1;stateChanges=new O;controlType="mat-input";autofilled=!1;get disabled(){return this._disabled}set disabled(e){this._disabled=de(e),this.focused&&(this.focused=!1,this.stateChanges.next())}_disabled=!1;get id(){return this._id}set id(e){this._id=e||this._uid}_id;placeholder;name;get required(){return this._required??this.ngControl?.control?.hasValidator(Le.required)??!1}set required(e){this._required=de(e)}_required;get type(){return this._type}set type(e){this._type=e||"text",this._validateType(),!this._isTextarea&&ht().has(this._type)&&(this._elementRef.nativeElement.type=this._type)}_type="text";get errorStateMatcher(){return this._errorStateTracker.matcher}set errorStateMatcher(e){this._errorStateTracker.matcher=e}userAriaDescribedBy;get value(){return this._signalBasedValueAccessor?this._signalBasedValueAccessor.value():this._inputValueAccessor.value}set value(e){e!==this.value&&(this._signalBasedValueAccessor?this._signalBasedValueAccessor.value.set(e):this._inputValueAccessor.value=e,this.stateChanges.next())}get readonly(){return this._readonly}set readonly(e){this._readonly=de(e)}_readonly=!1;disabledInteractive;get errorState(){return this._errorStateTracker.errorState}set errorState(e){this._errorStateTracker.errorState=e}_neverEmptyInputTypes=["date","datetime","datetime-local","month","time","week"].filter(e=>ht().has(e));constructor(){let e=m(De,{optional:!0}),n=m(Ft,{optional:!0}),r=m(Dn),o=m(wn,{optional:!0,self:!0}),l=this._elementRef.nativeElement,y=l.nodeName.toLowerCase();o?Xt(o.value)?this._signalBasedValueAccessor=o:this._inputValueAccessor=o:this._inputValueAccessor=l,this._previousNativeValue=this.value,this.id=this.id,this._platform.IOS&&this._ngZone.runOutsideAngular(()=>{this._cleanupIosKeyup=this._renderer.listen(l,"keyup",this._iOSKeyupListener)}),this._errorStateTracker=new nt(r,this.ngControl,n,e,this.stateChanges),this._isServer=!this._platform.isBrowser,this._isNativeSelect=y==="select",this._isTextarea=y==="textarea",this._isInFormField=!!this._formField,this.disabledInteractive=this._config?.disabledInteractive||!1,this._isNativeSelect&&(this.controlType=l.multiple?"mat-native-select-multiple":"mat-native-select"),this._signalBasedValueAccessor&&Ie(()=>{this._signalBasedValueAccessor.value(),this.stateChanges.next()})}ngAfterViewInit(){this._platform.isBrowser&&this._autofillMonitor.monitor(this._elementRef.nativeElement).subscribe(e=>{this.autofilled=e.isAutofilled,this.stateChanges.next()})}ngOnChanges(){this.stateChanges.next()}ngOnDestroy(){this.stateChanges.complete(),this._platform.isBrowser&&this._autofillMonitor.stopMonitoring(this._elementRef.nativeElement),this._cleanupIosKeyup?.(),this._cleanupWebkitWheel?.()}ngDoCheck(){this.ngControl&&(this.updateErrorState(),this.ngControl.disabled!==null&&this.ngControl.disabled!==this.disabled&&(this.disabled=this.ngControl.disabled,this.stateChanges.next())),this._dirtyCheckNativeValue(),this._dirtyCheckPlaceholder()}focus(e){this._elementRef.nativeElement.focus(e)}updateErrorState(){this._errorStateTracker.updateErrorState()}_focusChanged(e){if(e!==this.focused){if(!this._isNativeSelect&&e&&this.disabled&&this.disabledInteractive){let n=this._elementRef.nativeElement;n.type==="number"?(n.type="text",n.setSelectionRange(0,0),n.type="number"):n.setSelectionRange(0,0)}this.focused=e,this.stateChanges.next()}}_onInput(){}_dirtyCheckNativeValue(){let e=this._elementRef.nativeElement.value;this._previousNativeValue!==e&&(this._previousNativeValue=e,this.stateChanges.next())}_dirtyCheckPlaceholder(){let e=this._getPlaceholder();if(e!==this._previousPlaceholder){let n=this._elementRef.nativeElement;this._previousPlaceholder=e,e?n.setAttribute("placeholder",e):n.removeAttribute("placeholder")}}_getPlaceholder(){return this.placeholder||null}_validateType(){Xr.indexOf(this._type)>-1}_isNeverEmpty(){return this._neverEmptyInputTypes.indexOf(this._type)>-1}_isBadInput(){let e=this._elementRef.nativeElement.validity;return e&&e.badInput}get empty(){return!this._isNeverEmpty()&&!this._elementRef.nativeElement.value&&!this._isBadInput()&&!this.autofilled}get shouldLabelFloat(){if(this._isNativeSelect){let e=this._elementRef.nativeElement,n=e.options[0];return this.focused||e.multiple||!this.empty||!!(e.selectedIndex>-1&&n&&n.label)}else return this.focused&&!this.disabled||!this.empty}get describedByIds(){return this._elementRef.nativeElement.getAttribute("aria-describedby")?.split(" ")||[]}setDescribedByIds(e){let n=this._elementRef.nativeElement;e.length?n.setAttribute("aria-describedby",e.join(" ")):n.removeAttribute("aria-describedby")}onContainerClick(){this.focused||this.focus()}_isInlineSelect(){let e=this._elementRef.nativeElement;return this._isNativeSelect&&(e.multiple||e.size>1)}_iOSKeyupListener=e=>{let n=e.target;!n.value&&n.selectionStart===0&&n.selectionEnd===0&&(n.setSelectionRange(1,1),n.setSelectionRange(0,0))};_getReadonlyAttribute(){return this._isNativeSelect?null:this.readonly||this.disabled&&this.disabledInteractive?"true":null}static \u0275fac=function(n){return new(n||t)};static \u0275dir=h({type:t,selectors:[["input","matInput",""],["textarea","matInput",""],["select","matNativeControl",""],["input","matNativeControl",""],["textarea","matNativeControl",""]],hostAttrs:[1,"mat-mdc-input-element"],hostVars:21,hostBindings:function(n,r){n&1&&v("focus",function(){return r._focusChanged(!0)})("blur",function(){return r._focusChanged(!1)})("input",function(){return r._onInput()}),n&2&&(ke("id",r.id)("disabled",r.disabled&&!r.disabledInteractive)("required",r.required),T("name",r.name||null)("readonly",r._getReadonlyAttribute())("aria-disabled",r.disabled&&r.disabledInteractive?"true":null)("aria-invalid",r.empty&&r.required?null:r.errorState)("aria-required",r.required)("id",r.id),S("mat-input-server",r._isServer)("mat-mdc-form-field-textarea-control",r._isInFormField&&r._isTextarea)("mat-mdc-form-field-input-control",r._isInFormField)("mat-mdc-input-disabled-interactive",r.disabledInteractive)("mdc-text-field__input",r._isInFormField)("mat-mdc-native-select-inline",r._isInlineSelect()))},inputs:{disabled:"disabled",id:"id",placeholder:"placeholder",name:"name",required:"required",type:"type",errorStateMatcher:"errorStateMatcher",userAriaDescribedBy:[0,"aria-describedby","userAriaDescribedBy"],value:"value",readonly:"readonly",disabledInteractive:[2,"disabledInteractive","disabledInteractive",oe]},exportAs:["matInput"],features:[w([{provide:kt,useExisting:t}]),ne]})}return t})(),En=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275mod=R({type:t});static \u0275inj=P({imports:[Ee,Ee,Mn,se]})}return t})();var Sn=(()=>{class t{static \u0275fac=function(n){return new(n||t)};static \u0275mod=R({type:t});static \u0275inj=P({imports:[se]})}return t})();function no(t,i){t&1&&d(0," Conectar al servidor ")}function ro(t,i){t&1&&d(0," Crear una partida ")}function oo(t,i){t&1&&d(0," Unirse a una partida ")}function ao(t,i){t&1&&d(0," \xBFQu\xE9 quer\xE9s hacer? ")}function so(t,i){if(t&1&&(a(0,"div",26),d(1),s()),t&2){let e=u();c(),j(" ",e.mensajeError," ")}}function lo(t,i){if(t&1&&(a(0,"div",27),d(1),s()),t&2){let e=u();c(),j(" ",e.mensajeExito," ")}}function co(t,i){if(t&1){let e=$();a(0,"form",29),v("ngSubmit",function(){F(e);let r=u();return E(r.conectar())}),a(1,"mat-form-field",30)(2,"mat-label"),d(3,"Direcci\xF3n del servidor"),s(),a(4,"input",31),_e("ngModelChange",function(r){F(e);let o=u();return ge(o.direccionServidor,r)||(o.direccionServidor=r),E(r)}),s(),a(5,"mat-icon",32),d(6,"dns"),s()(),a(7,"button",33),d(8),s()()}if(t&2){let e=u();c(4),pe("ngModel",e.direccionServidor),_("disabled",e.cargando),c(3),_("disabled",e.cargando),c(),j(" ",e.cargando?"Conectando...":"Conectar"," ")}}function mo(t,i){if(t&1){let e=$();a(0,"div",28)(1,"button",34),v("click",function(){F(e);let r=u();return E(r.cambiarOpcion("crear"))}),a(2,"mat-icon"),d(3,"add"),s(),d(4," Crear una partida "),s(),a(5,"button",35),v("click",function(){F(e);let r=u();return E(r.cambiarOpcion("unirse"))}),a(6,"mat-icon"),d(7,"meeting_room"),s(),d(8," Unirse a una partida "),s()()}if(t&2){let e=u();c(),_("disabled",e.cargando),c(4),_("disabled",e.cargando)}}function uo(t,i){if(t&1){let e=$();a(0,"mat-form-field",30)(1,"mat-label"),d(2,"Puntos para ganar"),s(),a(3,"input",38),_e("ngModelChange",function(r){F(e);let o=u(2);return ge(o.puntosParaGanar,r)||(o.puntosParaGanar=r),E(r)}),s(),a(4,"mat-icon",32),d(5,"emoji_events"),s()(),a(6,"button",34),v("click",function(){F(e);let r=u(2);return E(r.crearPartida())}),d(7),s()}if(t&2){let e=u(2);c(3),pe("ngModel",e.puntosParaGanar),_("disabled",e.cargando),c(3),_("disabled",e.cargando),c(),j(" ",e.cargando?"Creando...":"Crear partida"," ")}}function fo(t,i){if(t&1){let e=$();a(0,"mat-form-field",30)(1,"mat-label"),d(2,"C\xF3digo de la partida"),s(),a(3,"input",39),_e("ngModelChange",function(r){F(e);let o=u(2);return ge(o.codigoPartida,r)||(o.codigoPartida=r),E(r)}),s(),a(4,"mat-icon",32),d(5,"vpn_key"),s()(),a(6,"button",34),v("click",function(){F(e);let r=u(2);return E(r.unirsePartida())}),d(7),s()}if(t&2){let e=u(2);c(3),pe("ngModel",e.codigoPartida),_("disabled",e.cargando),c(3),_("disabled",e.cargando),c(),j(" ",e.cargando?"Ingresando...":"Unirse"," ")}}function ho(t,i){if(t&1){let e=$();a(0,"div",28)(1,"mat-form-field",30)(2,"mat-label"),d(3,"Tu nombre"),s(),a(4,"input",36),_e("ngModelChange",function(r){F(e);let o=u();return ge(o.nombreJugador,r)||(o.nombreJugador=r),E(r)}),s(),a(5,"mat-icon",32),d(6,"person_outline"),s()(),p(7,uo,8,4)(8,fo,8,4),a(9,"button",37),v("click",function(){F(e);let r=u();return E(r.cambiarOpcion(""))}),a(10,"mat-icon"),d(11,"arrow_back"),s(),d(12," Volver "),s()()}if(t&2){let e=u();c(4),pe("ngModel",e.nombreJugador),_("disabled",e.cargando),c(3),g(e.opcion==="crear"?7:e.opcion==="unirse"?8:-1),c(2),_("disabled",e.cargando)}}var rt=class t{constructor(i,e,n){this.partidaService=i;this.cdr=e;this.router=n}partidaService;cdr;router;direccionServidor="";nombreJugador="";codigoPartida="";puntosParaGanar=null;cargando=!1;servicioDisponible=!1;mensajeError="";mensajeExito="";opcion="";direccionConectada="";ngOnInit(){this.direccionServidor=this.partidaService.obtenerServidor()}conectar(){if(this.cargando)return;this.limpiarMensajes(),this.servicioDisponible=!1;let i=this.direccionServidor.trim();if(!i){this.mensajeError="Ingres\xE1 la direcci\xF3n del servidor.";return}this.cargando=!0;try{this.partidaService.comprobarServicio(i).subscribe({next:()=>{try{this.partidaService.guardarServidor(i)}catch(e){this.mostrarError(e);return}this.direccionServidor=i,this.direccionConectada=i,this.servicioDisponible=!0,this.cargando=!1,this.mensajeExito="Conectado al servidor.",console.log("Conexi\xF3n correcta."),this.cdr.markForCheck()},error:e=>this.mostrarError(e)})}catch(e){this.mostrarError(e)}}crearPartida(){if(this.cargando||(this.limpiarMensajes(),!this.validarIngreso()))return;let i=this.puntosParaGanar;if(i===null||!Number.isInteger(i)||i<1||i>20){this.mensajeError="Ingres\xE1 un n\xFAmero entero entre 1 y 20 para los puntos.";return}this.cargando=!0,this.partidaService.crearPartida(this.nombreJugador,i).subscribe({next:e=>{this.entrarAlLobby(e,"Partida creada.")},error:e=>this.mostrarError(e)})}unirsePartida(){if(!this.cargando&&(this.limpiarMensajes(),!!this.validarIngreso())){if(this.codigoPartida=this.codigoPartida.trim(),!this.codigoPartida){this.mensajeError="Ingres\xE1 el c\xF3digo de la partida.";return}this.cargando=!0,this.partidaService.unirsePartida(this.codigoPartida,this.nombreJugador).subscribe({next:i=>{this.entrarAlLobby(i,"Te uniste a la partida.")},error:i=>this.mostrarError(i)})}}validarIngreso(){return!this.servicioDisponible||this.direccionServidor.trim()!==this.direccionConectada?(this.servicioDisponible=!1,this.mensajeError="Primero conectate al servidor.",!1):(this.nombreJugador=this.nombreJugador.trim(),this.nombreJugador.length<1||this.nombreJugador.length>24?(this.mensajeError="El nombre debe tener entre 1 y 24 caracteres.",!1):!0)}entrarAlLobby(i,e){try{this.partidaService.guardarSesion(i)}catch(n){this.mostrarError(n);return}this.cargando=!1,this.mensajeExito=e,console.log(e,"C\xF3digo:",i.partida_id),this.cdr.markForCheck(),this.router.navigate(["/lobby"])}mostrarError(i){this.cargando=!1,this.mensajeExito="",this.mensajeError=Si(i),console.error(this.mensajeError),this.cdr.markForCheck()}limpiarMensajes(){this.mensajeError="",this.mensajeExito=""}cambiarOpcion(i){this.cargando||(this.opcion=i,this.limpiarMensajes())}static \u0275fac=function(e){return new(e||t)(f(ce),f(Z),f(ae))};static \u0275cmp=A({type:t,selectors:[["app-home"]],decls:64,vars:4,consts:[[1,"home-page"],["viewBox","0 0 100 130","aria-hidden","true",1,"leaf-decor","leaf-a"],["fill","currentColor","d","M50 2C92 32 94 88 50 128C6 88 8 32 50 2Z"],["stroke","#fff","stroke-width","1.6","stroke-linecap","round","fill","none","d","M50 14V120M50 40L28 56M50 40L72 56M50 66L24 84M50 66L76 84M50 92L32 106M50 92L68 106"],["viewBox","0 0 100 130","aria-hidden","true",1,"leaf-decor","leaf-b"],["viewBox","0 0 100 130","aria-hidden","true",1,"leaf-decor","leaf-c"],[1,"home-container"],[1,"home-layout"],["aria-labelledby","game-title",1,"brand-section"],[1,"brand-mark"],[1,"brand-first"],[1,"brand-second"],[1,"xss-highlight"],[1,"brand-divider"],[1,"divider-leaf"],["id","game-title"],["aria-label","Ejemplo de cartas",1,"sample-cards"],[1,"sample-card","question-card"],[1,"card-label"],[1,"sample-card","answer-card"],[1,"sample-card","answer-card-alt"],["aria-labelledby","entry-title",1,"entry-section"],["aria-hidden","true",1,"entry-stamp"],[1,"entry-card"],[1,"entry-header"],["id","entry-title"],["role","alert",1,"form-message","error-message"],["role","status",1,"form-message","success-message"],[1,"entry-form"],[1,"entry-form",3,"ngSubmit"],["appearance","outline",1,"material-field"],["matInput","","name","direccionServidor","type","text","placeholder","https://servidor.com/#/","autocomplete","off","spellcheck","false","required","",3,"ngModelChange","ngModel","disabled"],["matPrefix",""],["mat-flat-button","","color","primary","type","submit",3,"disabled"],["mat-flat-button","","color","primary","type","button",3,"click","disabled"],["mat-stroked-button","","type","button",3,"click","disabled"],["matInput","","name","nombreJugador","type","text","placeholder","Ej. Alex","maxlength","24","autocomplete","nickname","required","",3,"ngModelChange","ngModel","disabled"],["mat-button","","type","button",3,"click","disabled"],["matInput","","name","puntosParaGanar","type","number","min","1","max","20","step","1","placeholder","Entre 1 y 20","required","",3,"ngModelChange","ngModel","disabled"],["matInput","","name","codigoPartida","type","text","placeholder","Peg\xE1 el c\xF3digo de la partida","autocomplete","off","spellcheck","false","required","",3,"ngModelChange","ngModel","disabled"]],template:function(e,n){e&1&&(a(0,"main",0),Zt(),a(1,"svg",1),x(2,"path",2)(3,"path",3),s(),a(4,"svg",4),x(5,"path",2)(6,"path",3),s(),a(7,"svg",5),x(8,"path",2),s(),Qt(),a(9,"div",6)(10,"div",7)(11,"section",8)(12,"div",9)(13,"span",10),d(14,"Cards for"),s(),a(15,"span",11),d(16," Democra"),a(17,"span",12),d(18,"XSS"),s(),d(19,"y "),s()(),a(20,"div",13),x(21,"span"),a(22,"span",14),d(23,"\u25C6"),s(),x(24,"span"),s(),a(25,"h1",15),d(26," Cartas, risas y mucha democracia. "),s(),a(27,"div",16)(28,"article",17)(29,"span",18),d(30,"LA PREGUNTA"),s(),a(31,"p"),d(32,"\xBFQu\xE9 har\xEDas si pudieras cambiar la pol\xEDtica del pa\xEDs?"),s()(),a(33,"article",19)(34,"span",18),d(35,"UNA RESPUESTA"),s(),a(36,"p"),d(37,"Un plan bien pensado... (o al menos eso dice el discurso)."),s()(),a(38,"article",20)(39,"span",18),d(40,"OTRA RESPUESTA"),s(),a(41,"p"),d(42,"Prometer mucho y firmar nada."),s()()()(),a(43,"section",21)(44,"div",22)(45,"span"),d(46,"\xA1QU\xC9"),s(),a(47,"strong"),d(48,"PURA"),s(),a(49,"strong"),d(50,"VIDA!"),s()(),a(51,"mat-card",23)(52,"mat-card-header",24)(53,"mat-card-title",25),p(54,no,1,0)(55,ro,1,0)(56,oo,1,0)(57,ao,1,0),s()(),a(58,"mat-card-content"),p(59,so,2,1,"div",26),p(60,lo,2,1,"div",27),p(61,co,9,4,"form",28)(62,mo,9,2,"div",28)(63,ho,13,4,"div",28),s()()()()()()),e&2&&(c(54),g(n.servicioDisponible?n.opcion==="crear"?55:n.opcion==="unirse"?56:57:54),c(5),g(n.mensajeError?59:-1),c(),g(n.mensajeExito?60:-1),c(),g(n.servicioDisponible?n.opcion===""?62:63:61))},dependencies:[ln,an,Je,Dt,Ji,Xi,Vt,At,St,Et,wt,De,Re,vi,xi,yi,bi,Ee,it,Fe,It,En,Fn,Te,Di,Ei,Fi,Sn],styles:['.home-page[_ngcontent-%COMP%]{position:relative;isolation:isolate;min-height:100vh;overflow:hidden;color:var(--color-ink);background:radial-gradient(ellipse at 10% 12%,#dce9df 0%,transparent 42%),linear-gradient(135deg,#f5f4eb,#e5eee6 52%,#d7e5dc)}.home-container[_ngcontent-%COMP%]{position:relative;z-index:1;width:min(var(--page-width),100%);margin:0 auto;padding:28px 6% 64px}.leaf-decor[_ngcontent-%COMP%]{position:absolute;z-index:-1;width:100px;height:130px;color:#9ebcac;opacity:.22;pointer-events:none}.leaf-a[_ngcontent-%COMP%]{top:17%;left:-28px;transform:rotate(-24deg)}.leaf-b[_ngcontent-%COMP%]{right:-24px;bottom:12%;transform:rotate(30deg)}.leaf-c[_ngcontent-%COMP%]{top:8%;right:14%;width:62px;height:81px;color:var(--color-coral);opacity:.14;transform:rotate(28deg)}.ticker[_ngcontent-%COMP%]{position:relative;z-index:2;width:100%;overflow:hidden;padding:11px 0;color:#fffaf2;background:var(--color-forest);font-size:.72rem;font-weight:700;letter-spacing:2.4px;white-space:nowrap}.ticker-track[_ngcontent-%COMP%]{display:flex;width:max-content;animation:_ngcontent-%COMP%_ticker-scroll 34s linear infinite}.ticker-track[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{flex:0 0 auto;padding-right:32px}.ticker-track[_ngcontent-%COMP%]   b[_ngcontent-%COMP%]{padding:0 9px;color:#e8a99c}@keyframes _ngcontent-%COMP%_ticker-scroll{0%{transform:translate(0)}to{transform:translate(-50%)}}.topbar[_ngcontent-%COMP%]{display:flex;justify-content:flex-end;align-items:center;min-height:42px;margin-bottom:24px}.status-pill[_ngcontent-%COMP%]{display:inline-flex;align-items:center;gap:9px;padding:9px 15px;color:var(--color-forest);background:#ffffff8c;border:1px solid rgb(22 74 63 / 12%);border-radius:999px;font-size:.78rem;font-weight:600}.status-dot[_ngcontent-%COMP%]{width:8px;height:8px;flex:0 0 8px;border-radius:50%;background:#5c9c78;box-shadow:0 0 0 4px #5c9c7821}.home-layout[_ngcontent-%COMP%]{display:grid;grid-template-columns:minmax(0,1.08fr) minmax(360px,.92fr);align-items:center;gap:clamp(42px,6vw,88px)}.brand-section[_ngcontent-%COMP%]{min-width:0;padding:12px 0 24px}.brand-mark[_ngcontent-%COMP%]{display:flex;flex-direction:column;align-items:flex-start;color:var(--color-forest)}.brand-first[_ngcontent-%COMP%]{margin-left:8px;font-size:clamp(1.1rem,2vw,1.45rem);font-weight:600;letter-spacing:5px}.brand-second[_ngcontent-%COMP%]{display:block;margin-top:1px;font-family:var(--font-display);font-size:clamp(4rem,7.2vw,6.8rem);font-weight:400;line-height:1.04;letter-spacing:-2px;white-space:nowrap}.xss-highlight[_ngcontent-%COMP%]{display:inline-block;padding:0 8px 3px;color:#fffaf2;background:var(--color-coral);border-radius:9px;font-family:var(--font-body);font-size:.49em;font-weight:800;letter-spacing:1px;vertical-align:18%;transform:rotate(-4deg)}.brand-divider[_ngcontent-%COMP%]{display:flex;align-items:center;gap:13px;width:min(340px,85%);margin:23px 0;color:var(--color-jade)}.brand-divider[_ngcontent-%COMP%] > span[_ngcontent-%COMP%]:not(.divider-leaf){height:1px;flex:1;background:#a8c2b4}.divider-leaf[_ngcontent-%COMP%]{font-size:.72rem}.brand-section[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{max-width:500px;margin:0;color:var(--color-forest);font-size:clamp(1.8rem,3.3vw,2.8rem);font-weight:700;line-height:1.18;letter-spacing:-1.2px}.sample-cards[_ngcontent-%COMP%]{display:flex;align-items:center;min-height:275px;margin:28px 0 8px 8px;padding:12px 0 22px}.sample-card[_ngcontent-%COMP%]{position:relative;display:flex;flex:1 1 0;flex-direction:column;align-self:center;min-width:0;min-height:215px;padding:23px 19px;border-radius:15px;box-shadow:var(--shadow-card);transition:transform .2s ease,box-shadow .2s ease}.sample-card[_ngcontent-%COMP%] + .sample-card[_ngcontent-%COMP%]{margin-left:-20px}.card-label[_ngcontent-%COMP%]{display:block;margin-bottom:19px;font-size:.62rem;font-weight:800;letter-spacing:1.3px;line-height:1.4}.sample-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:clamp(.83rem,1.15vw,1rem);font-weight:500;line-height:1.55;overflow-wrap:anywhere}.question-card[_ngcontent-%COMP%]{z-index:2;color:#fffdf5;background:var(--color-forest);transform:rotate(-5deg) translateY(-3px)}.question-card[_ngcontent-%COMP%]   .card-label[_ngcontent-%COMP%]{color:#b8d8c7}.answer-card[_ngcontent-%COMP%]{z-index:1;color:var(--color-forest);background:var(--color-cream);transform:rotate(3deg) translateY(9px)}.answer-card[_ngcontent-%COMP%]   .card-label[_ngcontent-%COMP%]{color:var(--color-jade)}.answer-card-alt[_ngcontent-%COMP%]{z-index:0;color:var(--color-forest);background:#e7c9bb;transform:rotate(7deg) translateY(1px)}.answer-card-alt[_ngcontent-%COMP%]   .card-label[_ngcontent-%COMP%]{color:#795347}.sample-card[_ngcontent-%COMP%]:hover{z-index:3;box-shadow:0 22px 42px #164a3f36;transform:translateY(-7px) rotate(0)}.entry-section[_ngcontent-%COMP%]{position:relative;min-width:0;padding-top:35px}.entry-stamp[_ngcontent-%COMP%]{position:absolute;z-index:2;top:0;right:-12px;display:flex;flex-direction:column;align-items:center;justify-content:center;width:94px;height:94px;color:var(--color-forest);background:#e6c5a9;border:2px solid rgb(22 74 63 / 25%);border-radius:50%;outline:1px dashed rgb(22 74 63 / 40%);outline-offset:-7px;box-shadow:0 6px 16px #164a3f1a;transform:rotate(10deg);pointer-events:none}.entry-stamp[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.58rem;font-weight:700;letter-spacing:1px}.entry-stamp[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.94rem;font-weight:900;line-height:1.05;letter-spacing:1px}.entry-card[_ngcontent-%COMP%]{display:block;width:100%;min-width:0;padding:34px;overflow:visible;color:var(--color-ink);background:#ffffffb0;border:1px solid rgb(255 255 255 / 85%);border-radius:25px;box-shadow:var(--shadow-card),inset 0 1px #fffc;backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px)}.entry-header[_ngcontent-%COMP%]{padding:0;margin:0 0 25px}.entry-card[_ngcontent-%COMP%]   mat-card-title[_ngcontent-%COMP%]{color:var(--color-forest);font-size:clamp(1.65rem,2.4vw,2.05rem);font-weight:750;line-height:1.2;letter-spacing:-.8px}.entry-card[_ngcontent-%COMP%]   mat-card-content[_ngcontent-%COMP%]{padding:0}.entry-form[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:12px}.form-group[_ngcontent-%COMP%]{display:flex;flex-direction:column;min-width:0}.form-group[_ngcontent-%COMP%] > label[_ngcontent-%COMP%]{margin-bottom:8px;color:var(--color-forest);font-size:.87rem;font-weight:700}.material-field[_ngcontent-%COMP%]{display:block;width:100%;min-width:0}.entry-form[_ngcontent-%COMP%]   .mat-mdc-text-field-wrapper[_ngcontent-%COMP%]{background:#ffffffc7;border-radius:10px}.entry-form[_ngcontent-%COMP%]   .mat-mdc-form-field-infix[_ngcontent-%COMP%]{min-height:54px}.entry-form[_ngcontent-%COMP%]   input[matInput][_ngcontent-%COMP%]{color:var(--color-forest);font-size:.94rem}.entry-form[_ngcontent-%COMP%]   input[matInput][_ngcontent-%COMP%]::placeholder{color:#849e92}.entry-form[_ngcontent-%COMP%]   .mat-mdc-form-field-icon-prefix[_ngcontent-%COMP%]{padding-right:8px;color:var(--color-jade)}.field-hint[_ngcontent-%COMP%]{margin:0 0 7px;color:var(--color-muted);font-size:.76rem;line-height:1.5}.action-button[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:flex-start;gap:10px;width:100%;min-height:52px;padding:0 16px;border-radius:var(--radius-medium)!important;font-size:.9rem;font-weight:700;text-align:left;transition:transform .18s ease,box-shadow .18s ease}.action-button[_ngcontent-%COMP%]   mat-icon[_ngcontent-%COMP%]{flex:0 0 auto}.button-arrow[_ngcontent-%COMP%]{margin-left:auto;font-size:1.15rem;transition:transform .18s ease}.action-button[_ngcontent-%COMP%]:hover   .button-arrow[_ngcontent-%COMP%]{transform:translate(3px)}.primary-button[_ngcontent-%COMP%]{margin-top:4px;color:#fff!important;background:linear-gradient(135deg,#438d7b,#287565)!important;box-shadow:0 8px 18px #2875652b}.primary-button[_ngcontent-%COMP%]:hover{box-shadow:0 11px 23px #28756540;transform:translateY(-1px)}.secondary-button[_ngcontent-%COMP%]{color:var(--color-forest)!important;background:#fff6!important;border:1px solid var(--color-border)!important}.secondary-button[_ngcontent-%COMP%]:hover{background:#fff!important}.join-details[_ngcontent-%COMP%]{width:100%}.join-summary[_ngcontent-%COMP%]{display:block;list-style:none;cursor:pointer}.join-summary[_ngcontent-%COMP%]::-webkit-details-marker{display:none}.join-summary[_ngcontent-%COMP%]::marker{content:""}.join-summary[_ngcontent-%COMP%]   .action-button[_ngcontent-%COMP%]{margin:0}.join-details[open][_ngcontent-%COMP%]   .button-arrow[_ngcontent-%COMP%]{transform:rotate(90deg)}.join-fields[_ngcontent-%COMP%]{display:flex;flex-direction:column;gap:4px;margin-top:16px;padding-top:18px;border-top:1px solid rgb(22 74 63 / 13%)}.join-fields[_ngcontent-%COMP%]   .field-hint[_ngcontent-%COMP%]{margin-top:-8px}.entry-card[_ngcontent-%COMP%]   mat-divider[_ngcontent-%COMP%]{margin:24px 0;border-top-color:#164a3f21}.game-rules[_ngcontent-%COMP%]{display:flex;align-items:flex-start;gap:13px}.game-rules[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%]{margin:0 0 9px;color:var(--color-forest);font-size:.9rem;font-weight:800}.game-rules[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:5px 0 0;color:var(--color-muted);font-size:.8rem;line-height:1.55}@media(max-width:480px){.ticker[_ngcontent-%COMP%]{padding:9px 0;font-size:.65rem;letter-spacing:1.7px}.home-container[_ngcontent-%COMP%]{padding:20px 18px 36px}.topbar[_ngcontent-%COMP%]{min-height:36px;margin-bottom:15px}.status-pill[_ngcontent-%COMP%]{padding:8px 11px;font-size:.72rem}.brand-first[_ngcontent-%COMP%]{margin-left:4px;font-size:1rem;letter-spacing:3.5px}.brand-second[_ngcontent-%COMP%]{font-size:clamp(3.25rem,13.5vw,4.2rem);letter-spacing:-1.5px}.xss-highlight[_ngcontent-%COMP%]{padding-right:5px;padding-left:5px}.brand-divider[_ngcontent-%COMP%]{margin:18px 0}.brand-section[_ngcontent-%COMP%]   h1[_ngcontent-%COMP%]{font-size:1.85rem;letter-spacing:-.7px}.sample-cards[_ngcontent-%COMP%]{min-height:205px;margin:20px 0 0;padding:12px 0 18px}.sample-card[_ngcontent-%COMP%]{min-height:174px;padding:17px 12px;border-radius:var(--radius-medium)}.sample-card[_ngcontent-%COMP%] + .sample-card[_ngcontent-%COMP%]{margin-left:-15px}.card-label[_ngcontent-%COMP%]{margin-bottom:12px;font-size:.52rem;letter-spacing:.7px}.sample-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:.78rem;line-height:1.45}.entry-section[_ngcontent-%COMP%]{padding-top:23px}.entry-stamp[_ngcontent-%COMP%]{top:0;right:3px;width:69px;height:69px}.entry-stamp[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{font-size:.48rem}.entry-stamp[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%]{font-size:.75rem}.entry-card[_ngcontent-%COMP%]{padding:27px 20px 23px;border-radius:var(--radius-large)}.entry-header[_ngcontent-%COMP%]{margin-bottom:22px}.entry-card[_ngcontent-%COMP%]   mat-card-title[_ngcontent-%COMP%]{max-width:220px;font-size:1.65rem}.action-button[_ngcontent-%COMP%]{padding:0 12px;font-size:.82rem}.game-rules[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{font-size:.77rem}.leaf-c[_ngcontent-%COMP%]{right:5%}}@media(prefers-reduced-motion:reduce){.ticker-track[_ngcontent-%COMP%]{animation:none}}.entry-form[_ngcontent-%COMP%]   mat-error[_ngcontent-%COMP%]{color:#c62828;font-size:12px;font-weight:500}.form-message.error-message[_ngcontent-%COMP%]{color:#b42318;background:#fff0ee;border:1px solid #f3b6ae;border-left:4px solid #d92d20;border-radius:10px;padding:12px 16px;margin-bottom:16px;font-size:14px;font-weight:600}.form-message.success-message[_ngcontent-%COMP%]{color:#176b46;background:#e5f5eb;border:1px solid #a6d9b8;border-radius:10px;padding:12px 14px;margin-bottom:16px;font-size:14px;font-weight:500}']})};var po=(t,i)=>i.id;function go(t,i){if(t&1){let e=$();a(0,"button",17),v("click",function(){F(e);let r=u(2);return E(r.startGame())}),d(1),s()}if(t&2){let e=u(2);_("disabled",e.startSeason),c(),j(" ",e.startSeason?"Iniciando partida...":"Iniciar partida")}}function _o(t,i){if(t&1&&(a(0,"p",18),d(1),s()),t&2){let e=u(2);c(),he(e.error)}}function vo(t,i){if(t&1&&re(0,go,2,2,"button",15)(1,_o,2,1,"p",16),t&2){let e=u();_("ngIf",e.esAnfitrion),c(),_("ngIf",e.error)}}function bo(t,i){if(t&1&&(a(0,"article",19)(1,"span",14),d(2,"\u265F\uFE0F S\xFAbdito"),s(),a(3,"p"),d(4),s()()),t&2){let e=u().$implicit;c(4),j("Jugador: ",e.nombre)}}function xo(t,i){if(t&1&&p(0,bo,5,1,"article",19),t&2){let e=i.$implicit;g(e.es_anfitrion?-1:0)}}var ot=class t{constructor(i,e,n){this.partidaService=i;this.cdr=e;this.router=n}partidaService;cdr;router;actualizacionSub;seasonId="";hostName="";esAnfitrion=!1;startSeason=!1;error="";listCodes=[];codesfseason={};jugadores=[];generateCode(){let i;do i=Math.floor(1e3+Math.random()*9e3).toString();while(this.listCodes.includes(i));return this.listCodes.push(i),i}addCode(){this.generateCode()}startGame(){if(!(!this.esAnfitrion||this.startSeason)){if(this.jugadores.length<4||this.jugadores.length>22||this.jugadores.length%2!==0){this.error="Se necesitan entre 4 y 22 jugadores y la cantidad debe ser par.";return}this.startSeason=!0,this.error="",this.partidaService.iniciar().subscribe({next:()=>{this.router.navigate(["/game"])},error:i=>{this.error=i.error?.error??"No se pudo iniciar la partida.",this.startSeason=!1,this.cdr.detectChanges()}})}}saveCode(i){let e=this.generateCode();this.codesfseason[i]=e,console.log("ID:",i),console.log("C\xF3digo asociado:",this.codesfseason[i])}ngOnInit(){let i=this.partidaService.obtenerSesion();if(!i){console.error("No hay una partida activa");return}if(this.seasonId=i.partidaId,this.saveCode(this.seasonId),this.actualizarJugadores(i.partida.jugadores),i.partida.fase!=="sala"){this.router.navigate(["/game"]);return}this.actualizacionSub=Bt(2e3).pipe(Ae(0),$t(()=>this.partidaService.obtener().pipe(Ut(e=>(console.error("ERROR AL CONSULTAR PARTIDA:",e),jt(null)))))).subscribe(e=>{if(!e){console.warn("No se recibieron datos de la partida");return}this.actualizarJugadores(e.jugadores),this.cdr.detectChanges(),e.fase&&e.fase!=="sala"&&(this.actualizacionSub?.unsubscribe(),this.router.navigate(["/game"]))})}actualizarJugadores(i){this.jugadores=[...i].map(n=>({id:n.id,nombre:n.nombre,es_anfitrion:n.es_anfitrion}));let e=this.jugadores.find(n=>n.es_anfitrion);this.hostName=e?.nombre??"Anfitri\xF3n no encontrado",this.esAnfitrion=e?.id===this.partidaService.obtenerSesion()?.jugadorId,console.log("Jugadores actualizados en ngular:",this.jugadores.length)}ngOnDestroy(){this.actualizacionSub?.unsubscribe()}static \u0275fac=function(e){return new(e||t)(f(ce),f(Z),f(ae))};static \u0275cmp=A({type:t,selectors:[["app-lobby-g"]],decls:29,vars:3,consts:[["lang","en"],["charset","utf-8"],["href",K`/`],["name","viewport","content","width=device-width, initial-scale=1"],["rel","icon","type","image/x-icon","href",K`favicon.ico`],["rel","preconnect","href",K`https://fonts.googleapis.com`],["rel","preconnect","href",K`https://fonts.gstatic.com`,"crossorigin",""],["href",K`https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500&display=swap`,"rel","stylesheet"],["href",K`https://fonts.googleapis.com/icon?family=Material+Icons`,"rel","stylesheet"],[1,"gameroom"],[1,"gameroom-label"],[1,"gameroom-id"],["aria-label","Jugadores de la sala",1,"sample-cards"],[1,"sample-card","question-card"],[1,"card-label"],["class","btn-iniciar",3,"disabled","click",4,"ngIf"],["class","error",4,"ngIf"],[1,"btn-iniciar",3,"click","disabled"],[1,"error"],[1,"sample-card","answer-card"]],template:function(e,n){e&1&&(a(0,"html",0)(1,"head"),x(2,"meta",1),a(3,"title"),d(4,"DemocraxssyFrontend"),s(),x(5,"base",2)(6,"meta",3)(7,"link",4)(8,"link",5)(9,"link",6)(10,"link",7)(11,"link",8),s(),a(12,"body")(13,"section")(14,"div",9)(15,"span",10),d(16,"\u{1F3AE} C\xF3digo de sala:"),s(),a(17,"span",11),d(18),s()()(),a(19,"section")(20,"div",12)(21,"article",13)(22,"span",14),d(23,"\u{1F451} Anfitri\xF3n-Soberano"),s(),a(24,"p"),d(25),s(),p(26,vo,2,2),s(),ei(27,xo,1,1,null,null,po),s()()()()),e&2&&(c(18),he(n.seasonId),c(7),j("Jugador: ",n.hostName),c(),g(n.esAnfitrion?26:-1),c(),ti(n.jugadores))},dependencies:[ui,ci,Re,Te],styles:["html[_ngcontent-%COMP%], body[_ngcontent-%COMP%]{margin:0;padding:0}.btn-iniciar[_ngcontent-%COMP%]{display:inline-flex;align-items:center;justify-content:center;padding:15px 32px;border:1px solid #387f70;border-radius:16px;background:linear-gradient(135deg,#164a3f,#387f70);color:#fff;font-size:15px;font-weight:700;letter-spacing:.3px;box-shadow:0 8px 20px #164a3f33;cursor:pointer;margin-top:25px;transition:transform .2s ease,box-shadow .2s ease}.parti[_ngcontent-%COMP%]{color:#9acd32}.btn-iniciar[_ngcontent-%COMP%]:hover{transform:translateY(-3px);box-shadow:0 12px 26px #164a3f47}.btn-iniciar[_ngcontent-%COMP%]:active{transform:scale(.98)}.btn-iniciar[_ngcontent-%COMP%]:disabled{opacity:.55;cursor:not-allowed;transform:none}[_nghost-%COMP%]{display:block;min-height:100vh;background:radial-gradient(ellipse at 10% 12%,#dce9df 0%,transparent 42%),linear-gradient(135deg,#f5f4eb,#e5eee6 52%,#d7e5dc)}.gameroom[_ngcontent-%COMP%]{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:12px;padding:18px 24px;margin:24px auto;width:fit-content;max-width:calc(100% - 32px);background:linear-gradient(135deg,#153d32,#285d49);border:1px solid #c5a65a;border-radius:16px;box-shadow:0 8px 22px #164a3f26;box-sizing:border-box}.gameroom-label[_ngcontent-%COMP%]{color:#fff;font-size:12px;font-weight:800;letter-spacing:1.5px}.gameroom-id[_ngcontent-%COMP%]{color:#f1d68c;font-size:22px;font-weight:800;letter-spacing:2px;overflow-wrap:anywhere}.error[_ngcontent-%COMP%]{color:red;font-weight:15px}.sample-cards[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));align-items:start;gap:24px;width:100%;box-sizing:border-box;margin:0;padding:32px}.sample-card[_ngcontent-%COMP%]{position:relative;display:flex;flex-direction:column;align-self:stretch;min-width:0;min-height:115px;margin:0;padding:23px 19px;border-radius:15px;box-shadow:var(--shadow-card);box-sizing:border-box}.card-label[_ngcontent-%COMP%]{display:block;margin-bottom:19px;font-size:20px;font-weight:800;letter-spacing:1.3px;line-height:1.4}.sample-card[_ngcontent-%COMP%]   p[_ngcontent-%COMP%]{margin:0;font-size:20px;font-weight:500;line-height:1.55;overflow-wrap:anywhere}.question-card[_ngcontent-%COMP%]{z-index:2;color:#fffdf5;background-color:#498063}.question-card[_ngcontent-%COMP%]   .card-label[_ngcontent-%COMP%]{color:#b8d8c7}.answer-card[_ngcontent-%COMP%]{z-index:1;color:var(--color-fores);background:var(--color-cream)}.answer-card[_ngcontent-%COMP%]   .card-label[_ngcontent-%COMP%]{color:var(--color-jade)}.answer-card-alt[_ngcontent-%COMP%]{z-index:0;color:var(--color-forest);background:#e7c9bb}.answer-card-alt[_ngcontent-%COMP%]   .card-label[_ngcontent-%COMP%]{color:#795347}.sample-card[_ngcontent-%COMP%]:hover{z-index:3;box-shadow:0 22px 42px #164a3f36;transform:translateY(-7px) rotate(0)}.container-cards[_ngcontent-%COMP%]{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:20px;width:100%}.ticker[_ngcontent-%COMP%]{position:relative;z-index:2;width:100%;overflow:hidden;padding:11px 0;color:#fffaf2;background:var(--color-forest);font-size:.72rem;font-weight:700;letter-spacing:2.4px;white-space:nowrap}.ticker-track[_ngcontent-%COMP%]{display:flex;width:max-content;animation:_ngcontent-%COMP%_ticker-scroll 34s linear infinite}.ticker-track[_ngcontent-%COMP%]   span[_ngcontent-%COMP%]{flex:0 0 auto;padding-right:32px}.ticker-track[_ngcontent-%COMP%]   b[_ngcontent-%COMP%]{padding:0 9px;color:#e8a99c}@keyframes _ngcontent-%COMP%_ticker-scroll{0%{transform:translate(0)}to{transform:translate(-50%)}}"]})};var An=()=>{let t=m(ce),i=m(ae);return t.haySesion()?!0:i.createUrlTree(["/"])};var On=[{path:"",component:rt},{path:"lobby",component:ot,canActivate:[An]},{path:"game",loadComponent:()=>import("./chunk-K6FFJTEL.js").then(t=>t.Juego)},{path:"winner",loadComponent:()=>import("./chunk-S2LAOJM7.js").then(t=>t.Ganador)},{path:"**",redirectTo:""}];var Pn={providers:[Yt(),gi(On),hi()]};var at=class t{static \u0275fac=function(e){return new(e||t)};static \u0275cmp=A({type:t,selectors:[["app-root"]],decls:1,vars:0,template:function(e,n){e&1&&x(0,"router-outlet")},dependencies:[pi],styles:[".home-page[_ngcontent-%COMP%]{position:relative;isolation:isolate;min-height:100vh;overflow:hidden;color:var(--color-ink);background:radial-gradient(ellipse at 10% 12%,#dce9df 0%,transparent 42%),linear-gradient(135deg,#f5f4eb,#e5eee6 52%,#d7e5dc)}"]})};fi(at,Pn).catch(t=>console.error(t));
